import { Injectable } from '@angular/core';
import { AstrologerModel, Employee } from './app/models/employee.model';
import { UserModel } from './app/models/employee.model';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  eventLIstById(id: any) {
    throw new Error('Method not implemented.');
  }
  constructor(private http: HttpClient , private router: Router){}

  updateAstrologer(astrologerModelObj: AstrologerModel, id: number) {
    throw new Error('Method not implemented.');
  }
  deleteAstrologer(id: any) {
    throw new Error('Method not implemented.');
  }
  getAstrologer() {
    throw new Error('Method not implemented.');
  }
  postAstrologer(astrologerModelObj: AstrologerModel) {
    throw new Error('Method not implemented.');
  }
  // deleteEmployee(event: any) {
  //   throw new Error('Method not implemented.');
  // }
  // postEmployee(employee: Employee) {
  //   throw new Error('Method not implemented.');
  // }
  // deleteEmployees(event: any) {
  //   throw new Error('Method not implemented.');
  // }
  // postEmployees(employee: Employee) {
  //   throw new Error('Method not implemented.');
  // }
  // getEmployees() {
  //   throw new Error('Method not implemented.');
  // }
}
 

 

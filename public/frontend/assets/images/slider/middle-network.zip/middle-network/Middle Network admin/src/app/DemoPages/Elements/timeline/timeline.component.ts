import {Component, OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PromoterModel } from 'src/app/models/employee.model';
import { ServiceService } from 'src/app/service.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styles: []
})
export class TimelineComponent implements OnInit {

  formValue !: FormGroup;
  promoterModelObj: PromoterModel = new PromoterModel();
  promoterData !: any;
  closeResult: string;
  showAdd!: boolean;
  showUpdate!: boolean;
  submitData = false;

  
    //filter
    searchText;

  constructor(private formbuilder: FormBuilder, private api: ServiceService, private modalService: NgbModal) {
  }

  ngOnInit() {
    this.formValue = this.formbuilder.group({
      name:['',[Validators.required]],

    })
    this.getAllPromoter();
  }

  clickAddPromoter() {
    this.formValue.reset();
    this.showAdd = false;
    this.showUpdate = true;
  }

  postPromoterDetails() {
    this.promoterModelObj.name = this.formValue.value.name;

    this.api.postPromoter(this.promoterModelObj).subscribe(res => {
      console.log(res);
      Swal.fire("Thank You...", 'You Submitted Successfully', 'success')
      // alert("Astrologer Added Successfully") 
      let ref = document.getElementById('cancel');
      ref?.click();
      this.formValue.reset();
      // this.closebutton.nativeElement.click();
      this.getAllPromoter();
    },
      err => {
        Swal.fire("Wrong", 'Something went wrong', 'error')
        // alert("Somthing went wrong");
      })
    this.submitData = false;

  }

  
  getAllPromoter(){
    this.api.getPromoter().subscribe(res =>{
      this.promoterData =res;
    })
  }

  deletePromoterById(row:any){
    if (confirm('Are you sure you want to delete the promoter?')) {
      const promoterId = row.id;
      this.api.deletePromoter(promoterId).subscribe(() => {
        Swal.fire('Deleted', 'Your file has been deleted', 'success');
        this.getAllPromoter();
      }, () => {
        Swal.fire('Error', 'Something went wrong while deleting the Promoter', 'error');
      });
    }
  }
  onEdit(row:any) {
    this.showAdd = true;
    this.showUpdate = false;
    this.promoterModelObj.id =row.id;
    this.formValue.patchValue({
      name: row.name,
      // status: row.status
    });
  }

  updatePromoterDetails() {
    this.promoterModelObj.name=this.formValue.value.name;

    const promoterId = this.promoterModelObj.id;
  
    this.api.updatePromoter(this.promoterModelObj,promoterId).subscribe(
      () => {
        Swal.fire("Updated", 'Your file has been updated', 'info').then(() => {
          this.modalService.dismissAll();
          this.formValue.reset();
          this.getAllPromoter();
        });
      },
      (error: any) => {
        Swal.fire("Error", 'Something went wrong while updating the image details', 'error');
      }
    );
  }

  onSubmit() {
    this.submitData = true;

    if (this.formValue.invalid) {
      return;
    }

    Swal.fire('Success', 'Form submitted successfully', 'success');
  }



    
// Modal Open
open(content) {
  this.submitData = true;
  this.modalService.open(content).result.then(
    () => { },
    (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
}


openCentred(content) {
  this.modalService.open(content, { centered: true });
}


private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return `with: ${reason}`;
  }
}
}

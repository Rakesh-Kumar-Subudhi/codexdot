import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-details-artist',
  templateUrl: './details-artist.component.html',

})
export class DetailsArtistComponent implements OnInit {
  id: any;
data:any;
  eventData !: any;
  formValue !: FormGroup;
  formbuilder: any;
  constructor(private route: ActivatedRoute, private api: ServiceService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id']; 
    this.artistLIst();
  }

  artistLIst() {
    this.api.artistLIstById(this.id).subscribe(data => {
      this.eventData = data;
      console.log(data);
    })
  }
}

import {Component, OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AffiliateModel } from 'src/app/models/employee.model';
import { ServiceService } from 'src/app/service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-controls',
  templateUrl: './controls.component.html',
  styles: []
})
export class ControlsComponent implements OnInit {

  formValue !: FormGroup;
  affiliateModelObj: AffiliateModel = new AffiliateModel();
  affiliateData !: any;
  closeResult: string;
  showAdd!: boolean;
  showUpdate!: boolean;
  submitData = false;

   //filter
   searchText;

  constructor(private formbuilder: FormBuilder, private api: ServiceService, private modalService: NgbModal) {
  }

  ngOnInit() {
    this.formValue = this.formbuilder.group({
      affiliate_link:['',[Validators.required]],

    })
    this.getAllAffiliate();
  }

  clickAddAffiliate() {
    this.formValue.reset();
    this.showAdd = false;
    this.showUpdate = true;
  }

  postAffiliateDetails() {
    this.affiliateModelObj.affiliate_link = this.formValue.value.affiliate_link;

    this.api.postAffiliate(this.affiliateModelObj).subscribe(res => {
      console.log(res);
      Swal.fire("Thank You...", 'You Submitted Successfully', 'success')
      // alert("Astrologer Added Successfully") 
      let ref = document.getElementById('cancel');
      ref?.click();
      this.formValue.reset();
      // this.closebutton.nativeElement.click();
      this.getAllAffiliate();
    },
      err => {
        Swal.fire("Wrong", 'Something went wrong', 'error')
        // alert("Somthing went wrong");
      })
    this.submitData = false;

  }

  getAllAffiliate(){
    this.api.getAffiliate().subscribe(res =>{
      this.affiliateData =res;
    })
  }

  deleteAffiliateById(row:any){
    if (confirm('Are you sure you want to delete the Affiliate?')) {
      const affiliateId = row.id;
      this.api.deleteAffiliate(affiliateId).subscribe(() => {
        Swal.fire('Deleted', 'Your file has been deleted', 'success');
        this.getAllAffiliate();
      }, () => {
        Swal.fire('Error', 'Something went wrong while deleting the Affiliate', 'error');
      });
    }
  }

  onEdit(row:any) {
    this.showAdd = true;
    this.showUpdate = false;
    this.affiliateModelObj.id =row.id;
    this.formValue.patchValue({
      affiliate_link: row.affiliate_link,
      // status: row.status
    });
  }

  updateAffiliateDetails() {
    this.affiliateModelObj.affiliate_link=this.formValue.value.affiliate_link;

    const affiliateId = this.affiliateModelObj.id;
  
    this.api.updateAffiliate(this.affiliateModelObj,affiliateId).subscribe(
      () => {
        Swal.fire("Updated", 'Your file has been updated', 'info').then(() => {
          this.modalService.dismissAll();
          this.formValue.reset();
          this.getAllAffiliate();
        });
      },
      (error: any) => {
        Swal.fire("Error", 'Something went wrong while updating the image details', 'error');
      }
    );
  }


  onSubmit() {
    this.submitData = true;

    if (this.formValue.invalid) {
      return;
    }

    Swal.fire('Success', 'Form submitted successfully', 'success');
  }

  
  // Modal Open
open(content) {
  this.submitData = true;
  this.modalService.open(content).result.then(
    () => { },
    (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
}


openCentred(content) {
  this.modalService.open(content, { centered: true });
}


private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return `with: ${reason}`;
  }
}
}

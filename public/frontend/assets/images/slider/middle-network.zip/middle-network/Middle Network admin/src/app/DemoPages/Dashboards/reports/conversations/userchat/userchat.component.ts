import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userchat',
  templateUrl: './userchat.component.html',
  styleUrls: ['./userchat.component.sass']
})
export class UserchatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

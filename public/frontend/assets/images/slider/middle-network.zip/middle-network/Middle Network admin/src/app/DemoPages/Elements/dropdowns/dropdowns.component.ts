import { HttpHeaders } from '@angular/common/http';
import {Component, OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { EventModel } from 'src/app/models/employee.model';
import { ServiceService } from 'src/app/service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-dropdowns',
  templateUrl: './dropdowns.component.html',
  styles: []
})
export class DropdownsComponent implements OnInit {

  formValue !: FormGroup;
  eventModelObj: EventModel = new EventModel();
  eventData !: any;
  closeResult: string;
  showAdd!: boolean;
  showUpdate!: boolean;
  submitData = false;
  image: File | undefined;


    //filter
    searchText;
    optionValue = [
      {value:'active',lebels:'active'},
      {value:'inactive',lebels:'inactive'}
     ]

  constructor(private formbuilder: FormBuilder, private api: ServiceService, private modalService: NgbModal) {
  }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      name: ['', [Validators.required]],
      venue:['',[Validators.required]],
      genres: ['', [Validators.required]],
      promoterId: ['', [Validators.required]],
      image: ['', [Validators.required]],
      cost: ['', [Validators.required]],
      age: ['', [Validators.required]],
      visibility: ['', [Validators.required]],
      description: ['', [Validators.required]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      startTime: ['', [Validators.required]],
      endTime: ['', [Validators.required]],

    });
  
    this.getAllEvents(); 
  }

  clickAddEvent() {
    this.formValue.reset();
    this.showAdd = false;
    this.showUpdate = true;
  }
  
  handleFileInput(event: any) {
    if (event.target.files.length > 0) {
      this.image = event.target.files[0];
    }
  }

  postEventDetails() {
    // Create a FormData object and append the image file
    const formData = new FormData();
    
    if (this.image) {
      formData.append('image', this.image);
    }
  
    // Append other fields from formValue if available
    if (this.formValue) {
      formData.append('name', this.formValue.get('name')?.value);
      formData.append('venue', this.formValue.get('venue')?.value);
      formData.append('genres', this.formValue.get('genres')?.value);
      formData.append('promoterId', this.formValue.get('promoterId')?.value);
      formData.append('cost', this.formValue.get('cost')?.value);
      formData.append('age', this.formValue.get('age')?.value);
      formData.append('visibility', this.formValue.get('visibility')?.value);
      formData.append('description', this.formValue.get('description')?.value);
      formData.append('startDate', this.formValue.get('startDate')?.value);
      formData.append('endDate', this.formValue.get('endDate')?.value);
      formData.append('startTime', this.formValue.get('startTime')?.value);
      formData.append('endTime', this.formValue.get('endTime')?.value);


    }
    console.log('datasubmit');
    
    // Make the API call and handle the response
    this.api.postEvent(formData).subscribe(
      (res) => {
        console.log(formData);
        if (res.status == 'success') {
          Swal.fire("Thank You...", 'You Submitted Successfully', 'success').then(() => {
            this.modalService.dismissAll();
            this.formValue.reset();
            this.getAllEvents();
          });
        } else {
          Swal.fire("Error", 'Something went wrong', 'error');
          console.log("error");
        }
      },
      (err) => {
        // Handle API call errors
        console.error(err);
      }
    );
  }


  getAllEvents() {
    this.api.getEvent()
      .subscribe(res => {
        this.eventData = res;
      })
  }
  // getAllEvents() {
  //   let headers = new HttpHeaders()
  //     .set("Authorization", `Bearer ${localStorage.getItem('token')}`);
  
  //   this.api.getEvent({ headers: headers }).subscribe(
  //     res => {
  //       this.eventData = res;
  //       console.log(this.eventData[2].id);
  //     },
  //     error => {
  //       console.log('Error fetching artist data:', error);
  //       // Handle error appropriately (e.g., show a message)
  //     }
  //   );
  // }

  deleteEventById(row:any){
    if (confirm('Are you sure you want to delete the event?')) {
      const eventId = row.id;
      this.api.deleteEvent(eventId).subscribe(() => {
        Swal.fire('Deleted', 'Your file has been deleted', 'success');
        this.getAllEvents();
      }, () => {
        Swal.fire('Error', 'Something went wrong while deleting the Event', 'error');
      });
    }
  }

  onEdit(row:any) {
    this.showAdd = true;
    this.showUpdate = false;
    this.eventModelObj.id =row.id;
    this.formValue.patchValue({
      name: row.name,
      venue:row.venue,
      genres:row.genres,
      promoterId:row.promoterId,
      image:row.image,
      cost:row.cost,
      age:row.age,
      visibility:row.visibility,
      description:row.description,
      startDate:row.startDate,
      endDate:row.endDate,
      startTime:row.startTime,
      endTime:row.endTime,

      // status: row.status
    });
  }
  
  updateEventDetails() {
    this.eventModelObj.name=this.formValue.value.name;
    this.eventModelObj.venue=this.formValue.value.venue;
    this.eventModelObj.genres=this.formValue.value.genres;
    this.eventModelObj.promoterId=this.formValue.value.promoterId;
    this.eventModelObj.cost=this.formValue.value.cost;
    this.eventModelObj.age=this.formValue.value.age;
    this.eventModelObj.visibility=this.formValue.value.visibility;
    this.eventModelObj.description=this.formValue.value.description;
    this.eventModelObj.startDate=this.formValue.value.startDate;
    this.eventModelObj.endDate=this.formValue.value.endDate;
    this.eventModelObj.startTime=this.formValue.value.startTime;
    this.eventModelObj.endTime=this.formValue.value.endTime;
  
    const imageId = this.eventModelObj.id;
    this.api.updateEvent(this.eventModelObj ,imageId).subscribe(
      () => {
        Swal.fire("Updated", 'Your file has been updated', 'info').then(() => {
          this.modalService.dismissAll();
          this.formValue.reset();
          this.getAllEvents();
        });
      },
      (error: any) => {
        Swal.fire("Error", 'Something went wrong while updating the image details', 'error');
      }
    );
  }

  toggle(row: any) {
    const currentApprove = row.approve;
    const newApprove = currentApprove === '1' ? '0' : '1'; // Swap '0' to '1' and '1' to '0'
    const confirmationMessage = `Are you sure you want to change the status to ${newApprove}?`;
  
    Swal.fire({
        title: 'Confirmation',
        text: confirmationMessage,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, change it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            const astrologerId = row.id;
            this.api.approveEventsUpdate({ status: newApprove }, astrologerId).subscribe(
                (response) => {
                    console.log('Status changed successfully');
                    this.getAllEvents();
                },
                (error) => {
                    console.log('Error changing status', error);
                }
            );
        }
    });
  }










  
// Modal Open
open(content) {
  this.submitData = true;
  this.modalService.open(content).result.then(
    () => { },
    (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
}


openCentred(content) {
  this.modalService.open(content, { centered: true });
}


private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return `with: ${reason}`;
  }
}


}

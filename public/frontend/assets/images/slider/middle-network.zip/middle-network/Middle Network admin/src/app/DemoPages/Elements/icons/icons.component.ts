import {Component, OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { EventModel } from 'src/app/models/employee.model';
import { ServiceService } from 'src/app/service.service';


@Component({
  selector: 'app-icons',
  templateUrl: './icons.component.html',
  styles: []
})
export class IconsComponent implements OnInit {

  formValue !: FormGroup;
  eventModelObj: EventModel = new EventModel();
  eventData !: any;
  closeResult: string;
  showAdd!: boolean;
  showUpdate!: boolean;
  submitData = false;
  image: File | undefined;

  constructor(private formbuilder: FormBuilder, private api: ServiceService, private modalService: NgbModal) {
  }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      name: ['', [Validators.required]],
      venue: ['', [Validators.required]],
      genres: ['', [Validators.required]],
      promoterId: ['', [Validators.required]],
      image: ['', [Validators.required]],
      cost: ['', [Validators.required]],
      age: ['', [Validators.required]],
      visibility: ['', [Validators.required]],
      description: ['', [Validators.required]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      startTime: ['', [Validators.required]],
      endTime: ['', [Validators.required]],

    });
  
    this.getAllEvents(); 
  }

  

  getAllEvents() {
    this.api.getEvent()
      .subscribe(res => {
        this.eventData = res;
      })
  }
}

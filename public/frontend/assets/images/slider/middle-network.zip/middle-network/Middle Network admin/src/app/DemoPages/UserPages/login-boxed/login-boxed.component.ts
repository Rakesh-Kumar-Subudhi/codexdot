import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service.service';
import { Router } from '@angular/router';   
import { tap } from 'rxjs/operators';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-login-boxed',
  templateUrl: './login-boxed.component.html',
  styles: []
})
export class LoginBoxedComponent implements OnInit {

  formGroup!: FormGroup;
  msgData:boolean;
  showPassword : boolean = false;
  constructor(private service: ServiceService, private fb: FormBuilder,private router : Router) { }
  ngOnInit(): void {
    this.getForm();
  }
  getForm() {
    this.formGroup = this.fb.group({
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required]),
    });
  }

  
  get email(){
    return this.formGroup.get('email')
  }
  get password(){
    return this.formGroup.get('password')
  }

  
  onCheckMailPassword() {
    let body={
      "email":this.email.value,
      "password":this.password.value
    }
    this.service.checkEmailPassword(body).subscribe((response) => {
      this.msgData =response.success
      if(this.msgData==false){
        alert('Worng Email or Password ');
      }
        
       else {
        // alert('Email does not exist');
        this.loginProcess();
      }
    });
  }


  // loginProcess() {
  //   if (this.formGroup.valid) {
  //     this.service.login(this.formGroup.value).pipe(
  //       tap((result) => {
  //         console.log(result);
  //         if (result.message) {
  //           console.log('login success');
  //           Swal.fire('Success', result.message, 'success').then(() => {
  //             this.router.navigate(['dashboard']);
  //           // Perform any additional actions after successful login
  //         });
  //       } else {
  //         console.log('login error');
  //         console.log(result);
  //         Swal.fire('Error', result.message, 'error');
  //         // Perform any additional actions after failed login
  //       }
  //     }),
  //   ).subscribe({
  //     error: (error) => {
  //       console.log('error');
  //       console.log(error);
  //       // Perform any additional error handling
  //     }
  //   });
  //   }
  // }
  loginProcess() {
    if (this.formGroup.valid) {
      this.service.login(this.formGroup.value).pipe(
        tap((result) => {
          console.log(result);
          if (result.token) { // Assuming your API returns a token upon successful login
            console.log('login success');
            
            // Store the token in local storage
            localStorage.setItem("token",JSON.stringify(result.token));
            
            Swal.fire('Success', result.message, 'success').then(() => {
              this.router.navigate(['dashboard']);
              // Perform any additional actions after successful login
            });
          } else {
            console.log('login error');
            console.log(result);
            Swal.fire('Error', result.message, 'error');
            // Perform any additional actions after failed login
          }
        }),
      ).subscribe({
        error: (error) => {
          console.log('error');
          console.log(error);
          // Perform any additional error handling
        }
      });
    }
  }


  
  

  togglePasswordVisibility(field: string): void {
    this.showPassword = !this.showPassword;
    const passwordField = this.formGroup.get(field);
    if (passwordField) {
      passwordField.setValidators(null);
      passwordField.updateValueAndValidity();
    }
  }
  inputType(controlName: string): string {
    const control = this.formGroup.get(controlName);
    return control && control.value && control.value.length > 0 ? 'password' : 'text';
  }



}

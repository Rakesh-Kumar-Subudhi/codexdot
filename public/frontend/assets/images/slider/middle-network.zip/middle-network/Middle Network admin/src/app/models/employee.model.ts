export class Employee {
  id?: number = 0;
  firstname: string = '';
  lastname: string = '';
  birthdate: string = '';
  gender: string = '';
  education: string = '';
  company: string = '';
  jobExperience: number = 0;
  salary: number = 0;
  profile: string = '';
  static astrologerModelObj: any;
  videoModelObj: any = {};
}
export class AstrologerModel {
  id: number = 0;
  // title: string = '';
  name: string = '';
  email: string = '';
  password: string = '';
  phone: string = '';
  astrologer_type: string = '';
  tags: string = '';
  gender: string = '';
  status: string = '';

}

export class UserModel {
  id: number = 0;
  firstName: string = '';
  lastName: string = '';
  email: string = '';
  number: string = '';
  gender: string = '';
  dob: string = '';
  status: string = '';
}

export class artistModel {
  id: number = 0;
  artist_name: string = '';
  email: string = '';
  password: string = '';
  profile_pic: any;
  instagram_id: string = '';
  spotify_id: string = '';
  contact_no: string = '';
  status: string = '';
}
export class EventModel {
  id: number = 0;
  name: string = '';
  venue: string = '';
  genres: string = '';
  promoterId: string = '';
  image: any;
  cost: string = '';
  age: string = '';
  visibility: string = '';
  description: string = '';
  startDate: string = '';
  endDate: string = '';
  startTime: string = '';
  endTime: string = '';

  status: string = '';

}

export class MagazineModel {
  id: number = 0;
  title: string = '';
  description: string = '';
  image: string = '';
  status: string = '';
}
export class PromoterModel{
  id:number =0;
  name:string ='';
  status: string = '';
}
export class AffiliateModel{
  id:number =0;
  affiliate_link:string='';
  status:string='';
}


export interface Payment {
  getPayments(): Payment[];
  getPayment(): Payment[];
  id: number;
  cardNumber: string;
  cardHolder: string;
  expirationDate: string;
  cvv: string;
}
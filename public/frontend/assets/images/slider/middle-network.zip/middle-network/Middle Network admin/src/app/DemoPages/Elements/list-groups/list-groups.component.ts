import {Component, OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MagazineModel } from 'src/app/models/employee.model';
import { ServiceService } from 'src/app/service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-list-groups',
  templateUrl: './list-groups.component.html',
  styles: []
})
export class ListGroupsComponent implements OnInit {
  formValue !: FormGroup;
  magazineModelObj: MagazineModel = new MagazineModel();
  magazineData !: any;
  closeResult: string;
  showAdd!: boolean;
  showUpdate!: boolean;
  submitData = false;
  image: File | undefined;

 //filter
 searchText;

  constructor(private formbuilder: FormBuilder, private api: ServiceService, private modalService: NgbModal) {
  }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      title: ['', [Validators.required]],
      description: ['', [Validators.required]],
      image: ['', [Validators.required]],

  });
  this.getAllMagazine();
}

clickAddMagazine() {
  this.formValue.reset();
  this.showAdd = false;
  this.showUpdate = true;
}

handleFileInput(event: any) {
  if (event.target.files.length > 0) {
    this.image = event.target.files[0];
  }
}

postMagazineDetails() {
  // Create a FormData object and append the image file
  const formData = new FormData();
  
  if (this.image) {
    formData.append('image', this.image);
  }

  // Append other fields from formValue if available
  if (this.formValue) {
    formData.append('title', this.formValue.get('title')?.value);
    formData.append('description', this.formValue.get('description')?.value);
  }
  console.log('datasubmit');
  
  // Make the API call and handle the response
  this.api.postMagazine(formData).subscribe(
    (res) => {
      console.log(formData);
      if (res.status == 'success') {
        Swal.fire("Thank You...", 'You Submitted Successfully', 'success').then(() => {
          this.modalService.dismissAll();
          this.formValue.reset();
          this.getAllMagazine();
        });
      } else {
        Swal.fire("Error", 'Something went wrong', 'error');
        console.log("error");
      }
    },
    (err) => {
      // Handle API call errors
      console.error(err);
    }
  );
}


getAllMagazine() {
  this.api.getMagazine()
    .subscribe(res => {
      this.magazineData = res;
    })
}


deleteMagazineById(row:any){
  if (confirm('Are you sure you want to delete the Magazine?')) {
    // const magazineId = row.id;
    this.api.deleteMagazine(row.id).subscribe(() => {
      Swal.fire('Deleted', 'Your file has been deleted', 'success');
      this.getAllMagazine();
    }, () => {
      Swal.fire('Error', 'Something went wrong while deleting the Magazine', 'error');
    });
  }
}

onEdit(row:any) {
  this.showAdd = true;
  this.showUpdate = false;
  this.magazineModelObj.id =row.id;
  this.formValue.patchValue({
    title: row.title,
    description:row.description,
    // status: row.status
  });
}

updateMagazineDetails() {
  this.magazineModelObj.title=this.formValue.value.title;
  this.magazineModelObj.description=this.formValue.value.description;
 
  const imageId = this.magazineModelObj.id;
  this.api.updateMagszine(this.magazineModelObj ,imageId).subscribe(
    () => {
      Swal.fire("Updated", 'Your file has been updated', 'info').then(() => {
        this.modalService.dismissAll();
        this.formValue.reset();
        this.getAllMagazine();
      });
    },
    (error: any) => {
      Swal.fire("Error", 'Something went wrong while updating the image details', 'error');
    }
  );
}

toggle(row: any) {
  const currentApprove = row.approve;
  const newApprove = currentApprove === '1' ? '0' : '1'; // Swap '0' to '1' and '1' to '0'
  const confirmationMessage = `Are you sure you want to change the status to ${newApprove}?`;

  Swal.fire({
      title: 'Confirmation',
      text: confirmationMessage,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, change it!',
      cancelButtonText: 'Cancel'
  }).then((result) => {
      if (result.isConfirmed) {
          const magazineId = row.id;
          this.api.approveUpdate({ status: newApprove }, magazineId).subscribe(
              (response) => {
                  console.log('Approve changed successfully');
                  this.getAllMagazine();
              },
              (error) => {
                  console.log('Error changing Approve', error);
              }
          );
      }
  });
}





    
// Modal Open
open(content) {
  this.submitData = true;
  this.modalService.open(content).result.then(
    () => { },
    (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
}


openCentred(content) {
  this.modalService.open(content, { centered: true });
}


private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return `with: ${reason}`;
  }
}
}

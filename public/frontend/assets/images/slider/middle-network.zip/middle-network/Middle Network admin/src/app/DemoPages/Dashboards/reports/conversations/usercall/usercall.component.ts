import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usercall',
  templateUrl: './usercall.component.html',
  styleUrls: ['./usercall.component.sass']
})
export class UsercallComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

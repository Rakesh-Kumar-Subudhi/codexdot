import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-details-events',
  templateUrl: './details-events.component.html'
 
})
export class DetailsEventsComponent implements OnInit {
  id: any;
data:any;
  eventData !: any;
  formValue !: FormGroup;
  formbuilder: any;
  constructor(private route: ActivatedRoute, private api: ServiceService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id']; 
    this.eventLIst();
  }

  eventLIst() {
    this.api.eventLIstById(this.id).subscribe(data => {
      this.eventData = data;
      console.log(data);
    })
  }
}

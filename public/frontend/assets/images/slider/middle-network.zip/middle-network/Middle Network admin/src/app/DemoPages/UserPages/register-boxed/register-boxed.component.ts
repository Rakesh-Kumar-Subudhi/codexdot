import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-register-boxed',
  templateUrl: './register-boxed.component.html',
  styles: []
})
export class RegisterBoxedComponent implements OnInit {
  formGroup!: FormGroup;
  submitted = false;
  msgData: boolean;
  showPassword : boolean = false;

  constructor( private authService : ServiceService ,private fb: FormBuilder,private router : Router) { }

  ngOnInit() {
    this.registerForm();
  }

  registerForm() {
    this.formGroup = this.fb.group({
      userName: new FormControl('',Validators.required),
      email: new FormControl('', [Validators.required, Validators.email]),
      mobileNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      password: new FormControl('', [Validators.required,Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}$")])
    });
  }
  
  get userName() {
    return this.formGroup.get('userName');
  }
  
    get email() {
    return this.formGroup.get('email');
  }
  get mobileNumber() {
    return this.formGroup.get('mobileNumber');
  }
 
  get password() {
    return this.formGroup.get('password');
  }
 
    onCheckMail() {
      let body={
        "userName":this.userName.value,
        "email":this.email.value,
        "password":this.password.value,
        "mobileNumber":this.mobileNumber.value,
      }
      this.authService.checkEmailExists(body).subscribe((response) => {
        this.msgData =response.exists
        if(this.msgData==true){
          alert('Email already exists');
        }
          
         else {
          // alert('Email does not exist');
          this.signUpProcess();
        }
      });
    }

  signUpProcess(){

    console.log(this.formGroup.value);
    if(this.formGroup.valid){
      this.authService.signUp(this.formGroup.value).subscribe(res => {
        Swal.fire({
          icon: 'success',
          title: 'Registered Successfully',
          text: 'Please contact admin for enable access',
        }).then(() => {
          this.router.navigate(['signIn']);
        });
      });
    } else {
      Swal.fire({
        icon: 'warning',
        title: 'Invalid Data',
        text: 'Please enter valid data',
      });
  }
}

togglePasswordVisibility(field: string): void {
  this.showPassword = !this.showPassword;
  const passwordField = this.formGroup.get(field);
  if (passwordField) {
    passwordField.setValidators(null);
    passwordField.updateValueAndValidity();
  }
}
inputType(controlName: string): string {
  const control = this.formGroup.get(controlName);
  return control && control.value && control.value.length > 0 ? 'password' : 'text';
}

}



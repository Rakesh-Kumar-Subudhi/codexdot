import {Component, HostListener, Input,TemplateRef} from '@angular/core';
import { Router } from '@angular/router';
import { faStar, faPlus } from '@fortawesome/free-solid-svg-icons';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-page-title',
  templateUrl: './page-title.component.html',
})
export class PageTitleComponent {

  faStar = faStar;
  faPlus = faPlus;

  @Input() heading;
  @Input() subheading;
  @Input() icon;
  closeResult: string;
  getDismissReason: any;
  modalRef:any;

constructor(private modalService: NgbModal ,private api: ServiceService, private router: Router){}

ngOnInit(): void {
 

}








   
open(content) {
  this.modalService.open(content).result.then((result) => {
    this.closeResult = `Closed with: ${result}`;
  }, (reason) => {
    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  });
}

openCentred(content) {
  this.modalService.open(content, {centered: true});
}

logout(): void {
  this.api.logout();
  this.router.navigate(['/login']);
}



}

// import { Content } from '@angular/compiler/src/render3/r3_ast';
import { HttpHeaders } from '@angular/common/http';
import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { artistModel } from 'src/app/models/employee.model';
import { ServiceService } from 'src/app/service.service';

import Swal from 'sweetalert2';


@Component({
  selector: 'app-standard',
  templateUrl: './standard.component.html'
})
export class StandardComponent implements OnInit {
  // @ViewChild('closebutton') closebutton;
  @Output() closeModalEvent = new EventEmitter<boolean>();

  formValue !: FormGroup;
  artistModelObj: artistModel = new artistModel();
  artistData !: any;
  closeResult: string;
  showAdd!: boolean;
  showUpdate!: boolean;
  submitData = false;
  images: File | undefined;

   //filter
   searchText;

   optionValue = [
    {value:'active',lebels:'active'},
    {value:'inactive',lebels:'inactive'}
   ]

  constructor(private formbuilder: FormBuilder, private api: ServiceService, private modalService: NgbModal) { }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      artist_name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      profile_pic: ['', [Validators.required]],
      instagram_id: ['', [Validators.required]],
      spotify_id: ['', [Validators.required]],
      contact_no: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
    });
    this.getAllArtist(); 
  }
  

  clickAddArtist() {
    this.formValue.reset();
    this.showAdd = false;
    this.showUpdate = true;
  }

handleFileInput(event: any) {
  if (event.target.files.length > 0) {
    this.images = event.target.files[0];
  }
}

postArtistDetails() {
  // Create a FormData object and append the image file
  const formData = new FormData();
  
  if (this.images) {
    formData.append('profile_pic', this.images);
  }

  // Append other fields from formValue if available
  if (this.formValue) {
    formData.append('artist_name', this.formValue.get('artist_name')?.value);
    formData.append('email', this.formValue.get('email')?.value);
    formData.append('password', this.formValue.get('password')?.value);
    formData.append('instagram_id', this.formValue.get('instagram_id')?.value);
    formData.append('spotify_id', this.formValue.get('spotify_id')?.value);
    formData.append('contact_no', this.formValue.get('contact_no')?.value);
  }
  console.log('datasubmit');
  
  // Make the API call and handle the response
  this.api.postArtist(formData).subscribe(
    (res) => {
      console.log(formData);
      if (res.status == 'success') {
        Swal.fire("Thank You...", 'You Submitted Successfully', 'success').then(() => {
          this.modalService.dismissAll();
          this.formValue.reset();
          this.getAllArtist();
        });
      } else {
        Swal.fire("Error", 'Something went wrong', 'error');
        console.log("error");
      }
    },
    (err) => {
      // Handle API call errors
      console.error(err);
    }
  );
}


getAllArtist() {
  this.api.getArtist()
    .subscribe(res => {
      this.artistData = res;
    })
}
  
    // getAllArtist() {
    //   let headers = new HttpHeaders()
    //     .set("Authorization", `Bearer ${localStorage.getItem('token')}`);
    
    //   this.api.getArtist({ headers: headers }).subscribe(
    //     res => {
    //       this.artistData = res;
    //       console.log(this.artistData[2].id);
    //     },
    //     error => {
    //       console.log('Error fetching artist data:', error);
    //       // Handle error appropriately (e.g., show a message)
    //     }
    //   );
    // }
  
    deleteArtistData(row: any) {
    if (confirm('Are you sure you want to delete the User?')) {
      this.api.deleteArtistApi(row.id).subscribe(() => {
        Swal.fire('Deleted', 'Your file has been deleted', 'success');
        this.getAllArtist();
      }, () => {
        Swal.fire('Error', 'Something went wrong while deleting the image', 'error');
      });
    }
  }

onEdit(row:any) {
  this.showAdd = true;
  this.showUpdate = false;
  this.artistModelObj.id =row.id;
  this.formValue.patchValue({
    artist_name: row.artist_name,
    email:row.email,
    password:row.password,
    profile_pic:row.profile_pic,
    instagram_id:row.instagram_id,
    spotify_id:row.spotify_id,
    contact_no:row.contact_no,
    // status: row.status
  });
}

updateArtistDetails() {
  this.artistModelObj.artist_name=this.formValue.value.artist_name;
  this.artistModelObj.email=this.formValue.value.email;
  this.artistModelObj.password=this.formValue.value.password;
  this.artistModelObj.instagram_id=this.formValue.value.instagram_id;
  this.artistModelObj.spotify_id=this.formValue.value.spotify_id;
  this.artistModelObj.contact_no=this.formValue.value.contact_no;


  const imageId = this.artistModelObj.id;
  this.api.updateArtist(this.artistModelObj ,imageId).subscribe(
    () => {
      Swal.fire("Updated", 'Your file has been updated', 'info').then(() => {
        this.modalService.dismissAll();
        this.formValue.reset();
        this.getAllArtist();
      });
    },
    (error: any) => {
      Swal.fire("Error", 'Something went wrong while updating the image details', 'error');
    }
  );
}

  


  statusUpdate(row: any) {
    const currentStatus = row.status;
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    const confirmationMessage = `Are you sure you want to change the status to ${newStatus}?`;
    Swal.fire({
      title: 'Confirmation',
      text: confirmationMessage,
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        const imageId = row.id;
        this.api.statusUpdateArtist( { status: newStatus },imageId).subscribe(
          (response) => {
            Swal.fire({
              title: 'Status Updated',
              text: response.message,
              icon: 'success'
            });
            // this.getAllVideo();
          },
          (error) => {
            Swal.fire({
              title: 'Error',
              text: error.message,
              icon: 'error'
            });
          }
        );
      }
    });
  }
 
  

  onSubmit() {
    this.submitData = true;

    if (this.formValue.invalid) {
      return;
    }

    Swal.fire('Success', 'Data submitted successfully', 'success');
  }


// Modal Open
open(content) {
  this.submitData = true;
  this.modalService.open(content).result.then(
    () => { },
    (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
}


openCentred(content) {
  this.modalService.open(content, { centered: true });
}


private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return `with: ${reason}`;
  }
}






}

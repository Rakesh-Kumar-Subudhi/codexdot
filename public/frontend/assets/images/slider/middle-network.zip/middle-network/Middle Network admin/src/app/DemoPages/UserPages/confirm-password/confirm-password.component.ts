import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service.service';
import { ValidationError } from 'validation-utils';

@Component({
  selector: 'app-confirm-password',
  templateUrl: './confirm-password.component.html',

})
export class ConfirmPasswordComponent implements OnInit {

  formGroup!: FormGroup;
  showPassword : boolean = false;
  constructor(private service: ServiceService,  private fb: FormBuilder,private router : Router) { }

  ngOnInit(): void {
    this.getForm();
  }
  getForm(){
    this.formGroup=this.fb.group({
      newPassword:new FormControl('', [Validators.required]),
      confirmPassword: new FormControl('', [Validators.required]),
    },
    { 
      validator: this.passwordMatchValidator
    });
  
  }

  passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
    const newPassword = control.get('newPassword');
    const confirmPassword = control.get('confirmPassword');

    if (newPassword.value !== confirmPassword.value) {
      return { 'passwordMismatch': true };
    }

    return null;
  }
  togglePasswordVisibility(field: string): void {
    this.showPassword = !this.showPassword;
    const passwordField = this.formGroup.get(field);
    if (passwordField) {
      passwordField.setValidators(null);
      passwordField.updateValueAndValidity();
    }
  }
  inputType(controlName: string): string {
    const control = this.formGroup.get(controlName);
    return control && control.value && control.value.length > 0 ? 'password' : 'text';
  }


}

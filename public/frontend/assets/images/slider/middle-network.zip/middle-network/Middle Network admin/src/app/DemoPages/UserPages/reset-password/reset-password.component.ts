import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service.service';
import { tap } from 'rxjs/operators';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html'
 
})
export class ResetPasswordComponent implements OnInit {

  formGroup!: FormGroup;
  showPassword : boolean = false;
  
  constructor(private service: ServiceService,  private fb: FormBuilder,private router : Router) { }

  ngOnInit(): void {
    this.formData();
  }

  formData(){
    this.formGroup = this.fb.group({
      email: new FormControl('', [Validators.required, Validators.email]),
      currentPassword: new FormControl('', [Validators.required]),
      newPassword:new FormControl('', [Validators.required]),
    })
  }

  get email(){
    return this.formGroup.get('email')
  }
  get currentPassword(){
    return this.formGroup.get('currentPassword')
  }

  get newPassword(){
    return this.formGroup.get('newPassword')
  }

  resetProcess(){
    if(this.formGroup.valid){
      this.service.reset(this.formGroup.value).pipe(
        tap((result)=>{
          console.log(result);
          if (result.message) {
            console.log('Reset success');
            Swal.fire('Success', result.message, 'success').then(() => {
              this.router.navigate(['login']);
            // Perform any additional actions after successful login
          });
        } else {
          console.log('Reset error');
          console.log(result);
          Swal.fire('Error', result.message, 'error');
          // Perform any additional actions after failed login
        }
      }),
    ).subscribe({
      error: (error) => {
        console.log('error');
        console.log(error);
        // Perform any additional error handling
      }
    });
    }

  }

  togglePasswordVisibility(field: string): void {
    this.showPassword = !this.showPassword;
    const passwordField = this.formGroup.get(field);
    if (passwordField) {
      passwordField.setValidators(null);
      passwordField.updateValueAndValidity();
    }
  }
  inputType(controlName: string): string {
    const control = this.formGroup.get(controlName);
    return control && control.value && control.value.length > 0 ? 'password' : 'text';
  }


}

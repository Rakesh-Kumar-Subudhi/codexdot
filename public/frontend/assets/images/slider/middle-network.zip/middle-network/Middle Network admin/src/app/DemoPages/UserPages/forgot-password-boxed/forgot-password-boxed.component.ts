import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-forgot-password-boxed',
  templateUrl: './forgot-password-boxed.component.html',
  styles: []
})
export class ForgotPasswordBoxedComponent implements OnInit {
  
  formGroup!:FormGroup;

  constructor(private service: ServiceService, private fb: FormBuilder,private router : Router ) { }

  ngOnInit() {
    this.getForm();
  }

  getForm(){
    this.formGroup=this.fb.group({
      mobileNumber: ['', [Validators.required, Validators.pattern("^[0-9]{10}$")]]
    });
  }

  get mobileNumber(){
    return this.formGroup.get('mobileNumber')
  }


 



}

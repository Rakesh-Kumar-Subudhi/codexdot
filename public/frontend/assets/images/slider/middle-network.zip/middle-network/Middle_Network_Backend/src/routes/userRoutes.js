const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController/userController');
let jwt = require("jsonwebtoken");

const validate = require('../helper/validate');
const upload = require("../middleware/upload");
const verifyUser = require("../middleware/auth"); 

//---------------------- User login-------------------//
router.post('/login', userController.userLogin); 

router.get('/login', verifyUser, (req, res) => {
    jwt.verify(req.token,"USER",(err,authData) => {
        if (err) {
            res.send({result: "Invalid Token"});
        } else{
            res.json({message: "You are logged in...", authData})
        }
    })
});

router.post('/signUp',userController.signUp);

router.post('/verify-otp',userController.verifyotp);

router.post('/reviews', upload.single("photo"), userController.addReviews); 

router.get('/reviews/:id', userController.getReviews); 

module.exports = router;
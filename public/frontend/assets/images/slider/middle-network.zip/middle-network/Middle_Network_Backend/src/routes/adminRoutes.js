const express = require('express');
const router = express.Router();
const adminController =require('../controllers/adminController/adminController');
const adminEventController =require('../controllers/adminController/adminEventController');
const adminMagazineController =require('../controllers/adminController/adminMagazineController');
const adminUserController =require('../controllers/adminController/adminUserController');
const validate = require('../helper/validate');
const upload = require("../middleware/upload");
const adminPromoterController = require('../controllers/adminController/adminPromoterController')
const adminAffiliateController = require('../controllers/adminController/adminAffiliateController')
const adminNewsController = require('../controllers/adminController/adminNewsController')

const authenticateAdmin = require("../middleware/auth");   


//-------------------------------------------------Registation Admin---------------------------------------------------//
router.post('/createAdmin', validate.adminValidation, adminController.createAdmin);               //admin create

//-------------------------------------------------- Admin login-------------------------------------------------------//
router.post('/login', adminController.adminLogin);                                                // admin login

// router.use(authenticateAdmin); //middleware for jwt auth applies to all below routes

//-------------------------------------------- Admin Artist CRUD APIs--------------------------------------------------//
router.post('/addArtist',upload.single("profile_pic"), adminController.addArtist);                // add artist
router.get('/getArtist/:id', adminController.getArtist);                                          // show artist by id
router.get('/getAllArtist', adminController.getAllArtist);                                        // show all artist
router.post('/changeArtistStatus/:id', adminController.changeArtistStatus);                       // change artist status
router.post('/deleteArtist/:id', adminController.deleteArtist);                                   // delete artist by id
router.post('/editArtist/:id',upload.single("profile_pic"), adminController.editArtist);          // delete artist by id

//-------------------------------------------- Admin Event CRUD APIs--------------------------------------------------//
router.post('/addEvent',upload.single("image"), adminEventController.addEvent);                   // add Event
router.get('/eventList', adminEventController.eventList);                                         // Event List
router.get('/eventList/:id', adminEventController.particularEvent);                               // Event List by id
router.get('/upcommingEvent', adminEventController.upcommingEvents);                              // Upcomming Event List
router.get('/historyEvent', adminEventController.historyEvents);                                  // history of Event List
router.post('/approveEvent/:id', adminEventController.approveEvent);                              // approve Event by id
router.post('/deleteEvent/:id', adminEventController.deleteEvent);                                // delete Event by id
router.post('/editEvent/:id',upload.single("image"), adminEventController.editEvent);             // edit Event by id

//-------------------------------------------- Admin Magazine CRUD APIs-----------------------------------------------//
router.post('/createMagazine',upload.single("image"), adminMagazineController.createMagazine);    // create Magazine
router.get('/getAllMagazine', adminMagazineController.getAllMagazine);                            // get ALL Magazines
router.get('/getMagazine/:id', adminMagazineController.getMagazineById);                          // get Magazines by ID
router.post('/deleteMagazine/:id', adminMagazineController.deleteMagazine);                       // delete Magazines by ID
router.post('/approveMagazine/:id', adminMagazineController.approveMagazine);                     // approve Magazines by ID
router.post('/editMagazine/:id',upload.single("image"), adminMagazineController.updateMagazine);  // approve Magazines by ID


//-------------------------------------------- Admin Promoter CRUD APIs-----------------------------------------------//
router.post('/createPromoter',adminPromoterController.createPromoter);    // create promoter
router.post('/updatePromoter/:id',adminPromoterController.updatePromoter);    // update promoter
router.get('/getAllPromoter',adminPromoterController.getAllPromoter);    // get all promoter
router.get('/getPromoterById/:id',adminPromoterController.getPromoterById);    // get promoter
router.post('/deletePromoter/:id',adminPromoterController.deletePromoter);    // create promoter


//Affiliate
router.post('/createAffiliate',validate.validateAffiliateLink,adminAffiliateController.createAffiliate);  //create Affiliate
router.post('/updateAffiliate/:id',adminAffiliateController.updateAffiliate);    // update Affiliate
router.get('/getAllAffiliate',adminAffiliateController.getAllAffiliate);    // get all Affiliate
router.post('/deleteAffiliate/:id',adminAffiliateController.deleteAffiliate);    // create Affiliate

//user
router.post('/createUser', upload.single("photo"), adminUserController.userAdminCreate); 
router.get('/getUsers', adminUserController.adminGetAllUser); 
router.get('/getUser/:id', adminUserController.adminGetUserById); 
router.post('/updateUser/:id', adminUserController.adminUpdateUser); 


//news
router.post('/createNews',adminNewsController.createNews)

module.exports = router;
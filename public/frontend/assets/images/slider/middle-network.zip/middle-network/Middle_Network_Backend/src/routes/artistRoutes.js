const express = require('express');
const router = express.Router();
const artistController = require('../controllers/artistController/artistController');
const upload = require("../middleware/upload");
let jwt = require("jsonwebtoken");

const validate = require('../helper/validate');
const verifyArtist = require("../middleware/auth");  

//---------------------- Artist login-------------------//
router.post('/login', artistController.artistLogin);    

router.get('/login', verifyArtist, (req, res) => {
    jwt.verify(req.token,"ARTIST",(err,authData) => {
        if (err) {
            res.send({result: "Invalid Token"});
        } else{
            res.json({message: "You are logged in...", authData})
        }
    })
});

router.post('/signUp',upload.single("profile_pic"), artistController.signUp);

// ------------------ Artist CRUD APIs -------------------//

// router.post('/addMusic',upload.single('video'), adminController.addMusic);   `
router.post('/editArtist/:id',artistController.editArtist); 



router.get('/signOut', artistController.signOut)

module.exports = router;
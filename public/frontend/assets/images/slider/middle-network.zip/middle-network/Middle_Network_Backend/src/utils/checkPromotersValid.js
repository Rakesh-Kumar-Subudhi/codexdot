const conn = require("../config/connection")

const checkPromoters = async (promoters) => {
  try {
    function asyncFunction(element) {
      return new Promise((resolve, reject) => {
        const checkPromotersQuery = "select * from promoters where id =?";
        conn.query(checkPromotersQuery, [element], (error, result) => {
          if (result.length !== 0) resolve(true);
          resolve(false);
        });
      });
    }

    const promises = promoters.map((element) => asyncFunction(element));

    const data =await Promise.all(promises)
      .then((results) => {
        // console.log(results);
        const dataArray = results.map(result => result);
        return dataArray;
      })
      .catch((error) => {
        console.error(error);
      });
    //   console.log(data)
      return data;
  } catch (error) {
    throw error;
  }
};

module.exports = { checkPromoters };
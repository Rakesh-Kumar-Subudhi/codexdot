const conn = require("../../config/connection");
const fs = require("fs");
const unlinkFile = require("../../utils/unLinkFile");
const { promisifyQuery } = require("../../utils/promisify"); //this is used to avoid callback hell to make database query 'promise' format

//..................................... CREATE MAGAZINE .....................................//
const createMagazine = async (req, res) => {
    try{
        const { title, description } = req.body;
        if (!title || !description) {
          if(req.file) {
            unlinkFile.unlinkFile(req.file.path);
          }
          return res.status(400).json({ error: "all fields are required" });
        }
        if(!req.file) return res.status(400).json({ error: "enter image" });
        const photoRegex = /\.(jpg|jpeg|png|gif|bmp)$/i;
        if (!photoRegex.test(req.file.path)) {
            unlinkFile.unlinkFile(req.file.path);
            return res.status(400).json({ error: "enter valid image" });
        }
        const image = req.file.path;
        const insertMagazineQuery = "insert into magazine (title,description,image) values (?,?,?)";
        const createMagazineResult = await promisifyQuery(insertMagazineQuery,[title,description,image]);
        if(createMagazineResult.affectedRows) return res.status(200).json({status:"success"})
    }catch(error){
        console.error(error);
        if(req.file) unlinkFile.unlinkFile(req.file.path);
        return res.status(500).json({error:"failed to create magazine"});
    }
};

//.................................... GET all MAGAZINE .....................................//
const getAllMagazine = async (req, res) => {
    try{
        const getAllMagazineQuery = "select * from magazine order by date_added desc";
        const getMagazineResult = await promisifyQuery(getAllMagazineQuery);
        if(getMagazineResult.length === 0) return res.status(404).json({error:"There is no magazine currently"});
        return res.status(200).json(getMagazineResult);
    }catch(error){
        console.error(error);
        return res.status(500).json({error:"failed to fetch all magazine"});
    }
};

//..................................... GET MAGAZINE by ID ..................................//
const getMagazineById = async (req, res) => {
    try{
        const {id} = req.params;
        const getMagazineQuery = "select * from magazine where id = ?";
        const getMagazineResult = await promisifyQuery(getMagazineQuery,[id]);
        if(getMagazineResult.length === 0) return res.status(404).json({error:"There is no magazine for this id"});
        return res.status(200).json(getMagazineResult);
    }catch(error){
        console.error(error);
        return res.status(500).json({error:"failed to fetch magazine"});
    }
};




const deleteMagazine = (req, res) => {
    const { id } = req.params;
    console.log(id)
    const getMagazine = "select * from  magazine where id = ? and status = 'active'";
    conn.query(getMagazine, [id], (error, result) => {
      if (error) {
        console.error(error);
        return res.status(500).json({ error: "somthing went wrong" });
      }
      if(result.length === 0) return res.status(404).json({ error: "Event not found" });
      const deleteImage = result[0].image;
      if (result[0].length !== 0) {
        const deleteEventQuery =
          "update  magazine set status = 'inactive' where id = ?";
        conn.query(deleteEventQuery, [id], (error, result) => {
          if (result.affectedRows === 1) {
            if(deleteImage) fs.unlinkSync(deleteImage);
            return res.status(200).json({ result: "success" });
          }
        });
      }
    });
  }; 


//..................................... Approve MAGAZINE by ID ...............................//
const approveMagazine = async (req, res) => {
    try{
        const {id} = req.params;

        const getMagazineQuery = "select * from magazine where id = ?";
        const getMagazineResult = await promisifyQuery(getMagazineQuery,[id]);
        if(getMagazineResult.length === 0) return res.status(404).json({error:"magazine not found"}); 

        const approveMagaszineQuery = "update magazine set approve = '1' where id = ? and status = 'active' and approve = '0'";
        const approveMagaszineResult = await promisifyQuery(approveMagaszineQuery,[id]);
        if(approveMagaszineResult.affectedRows===1) return res.status(200).json({status:"success"});

        return res.status(200).json({message:"magazine already approved"});
    }catch(error){
        console.error(error);
        return res.status(500).json({error:"failed to approve magazine"}); 
    }
};

//..................................... UPDATE MAGAZINE by ID ...............................//
const updateMagazine = async (req, res) => {
    try{
        const {title,description} = req.body;
        const {id} = req.params;

        const getMagazineQuery = "select * from magazine where id = ?";
        const getMagazineResult = await promisifyQuery(getMagazineQuery,[id]);
        if(getMagazineResult.length === 0) return res.status(404).json({error:"magazine not found"}); 
        
        let newTitle = title? title: getMagazineResult[0].title;
        let newDescription = description? description: getMagazineResult[0].description;
        let newImage = req.file? req.file.path: getMagazineResult[0].image;
        if(req.file) unlinkFile.unlinkFile(getMagazineResult[0].image);

        if(getMagazineResult[0].approve==="0") return res.status(400).json({message:"you need to approve the magazine first"});


        const updateMagazineQuery = "update magazine set title = ?,description=?,image = ? where id = ? and status = 'active' and approve = '1'";
        const updateMagazineResult = await promisifyQuery(updateMagazineQuery,[newTitle,newDescription,newImage,id]);

        if(updateMagazineResult.affectedRows===1) return res.status(200).json({status:"success"});
        

    }catch(error){
        console.error(error);
        if(req.file) unlinkFile.unlinkFile(req.file.path);
        return res.status(500).json({error:"failed to uodate Magazine"});
    }
};



module.exports = {
  createMagazine,
  getAllMagazine,
  getMagazineById,
  deleteMagazine,
  updateMagazine,
  approveMagazine
};
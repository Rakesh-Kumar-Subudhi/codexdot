const conn = require("../../config/connection");



// Endpoint to create an affiliate link and save it to the MySQL database
const createAffiliate = function (req, res) {
          const { affiliate_link } = req.body;
        
          // SQL query to insert the affiliate link into the database
          const insertQuery = 'INSERT INTO  affiliate (affiliate_link) VALUES (?)';
        
          conn.query(insertQuery, [affiliate_link], (err, results) => {
            if (err) {
              console.error('Error inserting affiliate link:', err);
              return res.status(500).json({ error: 'Internal Server Error' });
            }
        
            res.json({ message: 'Affiliate link added and saved successfully' });
          });
        };


    const updateAffiliate = function (req, res) {
          const affiliateId = req.params.id;
          const { affiliate_link } = req.body;

          // Check if 'name' is null or empty
          if (!affiliate_link) {
                    return res.status(400).json({ error: 'Affiliate link cannot be null or empty' });
          }

          // Update affiliate in the database based on the affiliate ID
          const updateQuery = 'UPDATE affiliate SET affiliate_link = ? WHERE id = ?';
          conn.query(updateQuery, [affiliate_link, affiliateId], (err, result) => {
                    if (err) {
                              console.error('Error updating affiliate:', err);
                              return res.status(500).json({ error: 'Internal server error' });
                    }

                    if (result.affectedRows === 0) {
                              return res.status(404).json({ error: 'Affiliate not found' });
                    }

                    // Successfully updated Affiliate
                    res.status(200).json({ message: 'Affiliate updated successfully' });
          });
};    


const getAllAffiliate = function(req, res)  {
          const query = 'SELECT * FROM affiliate';
        
          conn.query(query, (error, results) => {
            if (error) {
              console.error('Error fetching affiliate:', error);
              res.status(500).send('Error fetching affiliate');
            } else {
              res.status(200).json(results);
            }
          });
        };

  const deleteAffiliate = function(req,res) {
          const affiliateId = req.params.id;
        
          // Query to delete a affiliate by ID from the database
          const deleteQuery = 'DELETE FROM affiliate WHERE id = ?';
        
          conn.query(deleteQuery, [affiliateId], (err, result) => {
            if (err) {
              console.error('Error deleting the affiliate:', err);
              return res.status(500).json({ error: 'Internal server error' });
            }
        
            // Check if no rows were affected (affiliate not found)
            if (result.affectedRows === 0) {
              return res.status(404).json({ error: 'affiliate not found' });
            }
        
            // Successfully deleted the affiliate
            res.status(200).json({ message: 'affiliate deleted successfully' });
          });
        };

 module.exports = {
          createAffiliate,
          updateAffiliate,
          getAllAffiliate,
          deleteAffiliate
 }
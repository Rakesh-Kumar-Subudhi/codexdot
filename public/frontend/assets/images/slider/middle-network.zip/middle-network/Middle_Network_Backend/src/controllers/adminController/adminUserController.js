const { promisifyQuery } = require("../../utils/promisify");
const fs = require('fs');

const userAdminCreate = async (req, res) => {
  try {
    if(!req.file) {
      return res.status(400).json({error:"net profile pic"})
    }
  const photoRegex = /\.(jpg|jpeg|png|gif|bmp)$/i;
  const photo = req.file.path;
  if (!photoRegex.test(req.file.path)) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: "enter valid image" });
    }
  
    const { firstName, lastName, email, number, gender, dob } = req.body;
    if (!firstName || !lastName || !email || !number || !gender || !dob)
      return res.status(400).json({ error: "all fields are required." });

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(email))
      return res.status(400).json({ error: "enter a valid email." });

    const emailSearchQuery = "select * from users where email = ?";
    const emailSerachResult = await promisifyQuery(emailSearchQuery, [email]);
    if (emailSerachResult.length > 0)
      return res.status(400).json({ error: "email already exist." });

    const createUserQuery =
      "insert into users ( firstName,lastName,email,photo,number,gender,dob ) values (?,?,?,?,?,?,?)";
    const createUserResult = await promisifyQuery(createUserQuery, [
      firstName,
      lastName,
      email,
      photo,
      number,
      gender,
      dob,
    ]);
    if (createUserResult.affectedRows === 1)
      return res.status(200).json({ status: "success" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "failed to create user" });
  }
};

const adminGetAllUser = async (req, res) => {
  try {
    const userSearchQuery = "select * from users";
    const userSearchResult = await promisifyQuery(userSearchQuery);
    if (userSearchResult.length === 0)
      return res.status(200).json({ message: "there is no users currently" });
    else return res.status(200).json(userSearchResult);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "failed fetch users" });
  }
};

const adminGetUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const userSearchQuery = "select * from users where id = ?";
    const userSearchResult = await promisifyQuery(userSearchQuery, [id]);
    console.log(userSearchResult);
    if (userSearchResult.length === 0)
      return res
        .status(404)
        .json({ message: "there is no user currently with this id" });
    else return res.status(200).json(userSearchResult);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "failed fetch users" });
  }
};

const adminDeleteUser = (req, res) => {};

const adminUpdateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { firstName, lastName, email, number, gender, dob } = req.body;
    const userSearchQuery = "select * from users where id = ?";
    const userSearchResult = await promisifyQuery(userSearchQuery, [id]);

    if (userSearchResult.length === 0)
      return res.status(200).json({ message: "there is no users currently" });
    let newFirstName = firstName ? firstName : userSearchResult[0].firstName;
    let newLastName = lastName ? lastName : userSearchResult[0].lastName;
    let newEmail = email ? email : userSearchResult[0].email;
    let newNumber = number ? number : userSearchResult[0].number;
    let newGender = gender ? gender : userSearchResult[0].gender;
    let newDob = dob ? dob : userSearchResult[0].dob;

    const userUpdateQuery = "update users set firstName=?, lastName=?, email=?, number=?, gender=?, dob=? where id = ?";
    const userUpdateResult = await promisifyQuery(userUpdateQuery, [newFirstName, newLastName, newEmail, newNumber, newGender, newDob,id]);
    if(userUpdateResult.affectedRows===1) return res.status(200).json({ status: "success" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "failed fetch users" });
  }
};

module.exports = {
  userAdminCreate,
  adminGetAllUser,
  adminGetUserById,
  adminUpdateUser,
};
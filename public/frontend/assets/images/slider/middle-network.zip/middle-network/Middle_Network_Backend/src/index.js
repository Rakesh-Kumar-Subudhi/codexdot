const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const axios = require('axios');
const session = require('express-session');
const adminRouter = require("./routes/adminRoutes");
var hbs = require('handlebars');
const otpGenerator = require('otp-generator');
const nodemailer = require('nodemailer');

const cors = require("cors");
require("dotenv").config();

// Setup server port
const port = process.env.PORT || 3000;
// create express app
const app = express();
app.use(
  cors({
    origin: "http://localhost:4200",
  })
);

// handlebars view engine
app.set('view engine', 'hbs');

// Spotify API credentials
const clientId = '13c836c500ae440aa9acf579c73319c2';
const clientSecret = '3474a19fcf66406fb7e962be003b1f41';

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
// parse requests of content-type - application/json
app.use(bodyParser.json());

//session middleware
app.use(session({
  secret: 'thisismysecrctekey',
  resave: false,
  saveUninitialized: true,
}));

app.use("/admin", adminRouter);

app.use("/artist", require("./routes/artistRoutes"));
app.use("/user", require("./routes/userRoutes"));

// define a root route
app.get("/", (req, res) => {
  res.send("Hello World");
});

// artist-id to fetch podcast data - 3pQ4aA7dkolyjUAMrVScgh

app.get('/podcast/:id', async (req, res) => {
  const artistId = req.params.id;
  try {
    const token = await getAccessToken();
    const [albumsResponse] = await Promise.all([
      axios.get(`https://api.spotify.com/v1/artists/${artistId}/albums?market=US&limit=8`, {
        headers: {
          'authorization': `Bearer ${token}`,
        },
      }),
    ]);

    const albums = albumsResponse.data.items; 
    // const podcasts = podcastsResponse.data.shows; 

    // res.render('index', { albums});
    res.json(albums);
  } catch (error) {
    console.error('Error fetching media:', error.message);
    res.status(500).send('Internal Server Error');
  }
});

// Function to fetch Spotify access token
async function getAccessToken() {
  try {
    const response = await axios.post(
      'https://accounts.spotify.com/api/token',
      'grant_type=client_credentials',
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        auth: {
          username: clientId,
          password: clientSecret,
        },
      }
    );

    return response.data.access_token;
  } catch (error) {
    throw error;
  }
}

// listen for requests
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});

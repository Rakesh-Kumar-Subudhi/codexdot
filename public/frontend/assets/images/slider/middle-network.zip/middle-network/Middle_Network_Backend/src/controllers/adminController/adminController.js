const conn = require("../../config/connection");
let jwt = require("jsonwebtoken");
const fs = require("fs");
const bcrypt = require("bcrypt");

//---------------------------------------Login Admin By email and password---------------------------------------//

exports.adminLogin = function (req, res) {
  const { email, password } = req.body;

  // Check if the user exists
  conn.query("SELECT * FROM admin WHERE email = ?", [email], (err, results) => {
    if (err) {
      console.error("Error querying the database:", err);
      res.status(500).json({ error: "Internal server error" });
      return;
    }

    if (results.length === 0) {
      res.status(404).json({ error: "Admin not found" });
      return;
    }

    const user = results[0];

    // Compare the password with the hashed password
    bcrypt.compare(password, user.password, (err, passwordMatch) => {
      if (err) {
        console.error("Error comparing passwords:", err);
        res.status(500).json({ error: "Internal server error" });
        return;
      }

      if (!passwordMatch) {
        res.status(401).json({ error: "Invalid password" });
        return;
      }

      // Generate a JWT token
      const token = jwt.sign({ email, password }, "ADMIN");

      res.status(200).json({ message: "Login successful", token });
    });
  });
};

//----------------------------------------------Create Admin-----------------------------------------------------//

exports.createAdmin = function (req, res) {
  const { userName, email, password, mobileNumber } = req.body;

  // Check if the user already exists
  conn.query(
    "SELECT * FROM admin WHERE email = ? OR mobileNumber = ?",
    [email, mobileNumber],
    (err, results) => {
      if (err) {
        console.error("Error querying the database:", err);
        return res.status(500).json({ error: "Internal server error" });
      }

      if (results.length > 0) {
        const existingUser = results.find((user) => user.email === email);
        if (existingUser) {
          return res.status(409).json({ error: "Email already exists" });
        } else {
          return res
            .status(409)
            .json({ error: "Mobile number already exists" });
        }
      }

      // Hash the password
      bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) {
          console.error("Error hashing password:", err);
          return res.status(500).json({ error: "Internal server error" });
        }

        // Create a new user in the database
        const newUser = {
          userName,
          email,
          password: hashedPassword,
          mobileNumber,
        };

        conn.query("INSERT INTO admin SET ?", newUser, (err) => {
          if (err) {
            console.error("Error creating user:", err);
            return res.status(500).json({ error: "Internal server error" });
          }

          console.log("Admin created successfully");

          // Generate token
          const token = jwt.sign({ email }, "your_secret_key"); // Replace 'your_secret_key' with your actual secret key

          return res.status(200).json({ token }); // Send the token in the response
        });
      });
    }
  );
};

//............................................. ADD ARTIST ..........................................//

exports.addArtist = async (req, res) => {
  if(!req.file) return res.status(400).json({error:"net profile pic"})
  const profile_pic = req.file.path;
  const { artist_name, email, password, instagram_id, spotify_id, contact_no } = req.body;
  if (
    !artist_name ||
    !email ||
    !password ||
    !instagram_id ||
    !spotify_id ||
    !contact_no
  )
    return res.status(400).json({ error: "all fileds are required" });

  const photoRegex = /\.(jpg|jpeg|png|gif|bmp)$/i;
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const passwordRegex =/^[a-zA-Z0-9!@#$%^&*]{6,16}$/;

  if (!emailRegex.test(email))
    return res.status(400).json({ error: "enter valid mail" });
  if (!passwordRegex.test(password))
    return res.status(400).json({ error: "enter strong passowrd add artist" });
  if (!photoRegex.test(req.file.path)) {
    fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: "enter valid image" });
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const existingArtist = "select email from artist where email = ?";
  conn.query(existingArtist, [email], (error, result) => {
    if (error) {
      console.error(error);
      return res.status(500).json({ error: "failed to get artist" });
    }
    if (result.length !== 0) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: "user already exist" });
    }
    const addArtistQuery =
      "insert into artist (artist_name, email, password,profile_pic, instagram_id, spotify_id, contact_no) values (?,?,?,?,?,?,?)";
    conn.query(
      addArtistQuery,
      [
        artist_name,
        email,
        hashedPassword,
        profile_pic,
        instagram_id,
        spotify_id,
        contact_no,
      ],
      (error, result) => {
        if (error) {
          console.error(error);
          fs.unlinkSync(req.file.path);
          return res.status(500).json({ error: "Failed to Add Artist" });
        }
        return res.status(200).json({ status: "success" });
      }
    );
  });
};

//............................................. SHOW ARTIST by ID ..........................................//

exports.getArtist = (req, res) => {
  const { id } = req.params;
  const getArtistQuery = "select * from artist where id = ?";
  conn.query(getArtistQuery, [id], (error, result) => {
    if (error) {
      console.error(error);
      return res.status(500).json({ error: `Failed to get Artist` });
    }
    if (result.length === 0)
      return res.status(200).json({ message: "There is not artist currently" });
    return res.status(200).json( result );
  });
};

//............................................. SHOW ALL ARTIST .............................................//

exports.getAllArtist = (req, res) => {
  const getAllArtistQuery = "select * from artist";
  conn.query(getAllArtistQuery, (error, result) => {
    if (error) {
      console.error(error);
      return res.status(500).json({ error: "failed to get list of artist" });
    }
    if (result.length === 0)
      return res.status(200).json({ message: "There is not artist currently" });

    return res.status(200).json(result);
  });
};

//............................................. CHANGE ARTIST STATUS .........................................//

exports.changeArtistStatus = (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const changeStatusQuery = "update artist set status = ? where id = ?";
  conn.query(changeStatusQuery, [status, id], (error, result) => {
    if (error) {
      console.error(error);
      return res.status(500).json({ error: "Failed to update status" });
    }
    return res.status(200).json({ status: "success" });
  });
};

//............................................. DELETE ARTIST  ..............................................//

exports.deleteArtist = (req, res) => {
  const { id } = req.params;
  console.log(id)
  const getArtist = "select * from artist where id = ? and status = 'active'";
  conn.query(getArtist, [id], (error, result) => {
    if (error) {
      console.error(error);
      return res.status(500).json({ error: "somthing went wrong" });
    }
    if(result.length === 0) return res.status(404).json({ error: "artist not found" });
    const deleteImage = result[0].profile_pic;
    if (result[0].length !== 0) {
      const deleteArtistQuery =
        "update artist set status = 'inactive' where id = ?";
      conn.query(deleteArtistQuery, [id], (error, result) => {
        if (result.affectedRows === 1) {
          if(deleteImage) fs.unlinkSync(deleteImage);
          return res.status(200).json({ result: "success" });
        }
      });
    }
  });
};  






//................................................ EDIT ARTIST  .............................................//

exports.editArtist = (req, res) => {
  const { id } = req.params;
  // const profile_pic = req.file.path;
  const { artist_name, email, password, instagram_id, spotify_id, contact_no } =
    req.body;

  const existingArtistSearchQuery = "select * from artist where id = ?";
  conn.query(existingArtistSearchQuery, [id], async (error, result) => {
    try{
      if (result.length === 0) {
        if(req.file) fs.unlinkSync(req.file.path);
        return res.status(404).json({ error: "artist not found" });
      }
  
      const updateQuery =
        "update artist set artist_name=?, email=?, password=?,profile_pic=?, instagram_id=?, spotify_id=?, contact_no=? where id = ?";
      let name = artist_name ? artist_name : result[0].artist_name;
      let mail = email ? email : result[0].email;
      let pass = password ? password : result[0].password;
      let insta = instagram_id ? instagram_id : result[0].instagram_id;
      let spotify = spotify_id ? spotify_id : result[0].spotify_id;
      let no = contact_no ? contact_no : result[0].contact_no;
      let pic = "";
  
      const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
      const passwordRegex =/^[a-zA-Z0-9!@#$%^&*]{6,16}$/;
      if (email) {
        if (!emailRegex.test(mail))
          return res.status(400).json({ error: "enter valid mail" });
      }
      console.log(password)
      if (password) {
        if (!passwordRegex.test(pass)) return res.status(400).json({ error: "enter strong passowrd hhhhh" });
      }
      pass = await bcrypt.hash(pass, 10);
      if (req.file) {
        fs.unlinkSync(result[0].profile_pic);
        pic = req.file.path;
      } 
      conn.query(
        updateQuery,
        [name, mail, pass, pic, insta, spotify, no, id],
        (error, result) => {
          if (error) {
            console.error(error);
            return res.status(500).json({ error: "failed to update" });
          }
          return res.status(200).json({ status: "success" });
        }
      );
    }catch(error){
      console.error(error);
      return res.status(500).json({ error: "failed to get artist" });
    }
  });
}
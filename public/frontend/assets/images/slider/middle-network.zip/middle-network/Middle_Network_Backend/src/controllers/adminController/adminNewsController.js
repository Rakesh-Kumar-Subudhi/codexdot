const conn = require("../../config/connection");
const puppeteer = require('puppeteer'); 

// Create a new news article and scrape data
const createNews = async function(req,res) {
          const { url } = req.body;
          if (!url) {
            res.status(400).json({ error: 'URL is required' });
            return;
          }
        
          try {
            const browser = await puppeteer.launch();
            const page = await browser.newPage();
            await page.goto(url);
        
            const title = await page.title();
            const content = await page.evaluate(() => {
            });
        
            await browser.close();
        
            // Now, insert the scraped data into the MySQL database
            const insertSql = 'INSERT INTO news (title, content) VALUES (?, ?)';
            conn.query(insertSql, [title, content], (err, result) => {
              if (err) {
                console.error('Error creating news article:', err);
                res.status(500).json({ error: 'Internal Server Error' });
                return;
              }
              res.json({ message: 'News article created successfully' });
            });
          } catch (error) {
            console.error('Error scraping news:', error);
            res.status(500).json({ error: 'Internal Server Error' });
          }
        };

        module.exports ={
          createNews
        }
        
const conn = require("../../config/connection");
const fs = require("fs");
const unlinkFile = require("../../utils/unLinkFile");
const checkPromotersValid = require("../../utils/checkPromotersValid");


//.......................................... ADMIN can ADD EVENT ......................................//
const addEvent = async (req, res) => {
          console.log(req.file)
  if (!req.file) return res.status(400).json({ error: "enter an image" });
  const image = req.file.path;
  const photoRegex = /\.(jpg|jpeg|png|gif|bmp)$/i;
  if (!photoRegex.test(req.file.path)) {
    unlinkFile.unlinkFile(req.file.path);
    return res.status(400).json({ error: "enter valid image" });
  }
  const {
    name,
    venue,
    genres,
    promoterId,
    cost,
    age,
    visibility,
    description,
    startDate,
    endDate,
    startTime,
    endTime,
  } = req.body;
  if (
    !name ||
    !venue ||
    !genres ||
    !promoterId ||
    !cost ||
    !age ||
    !visibility ||
    !description ||
    !startDate ||
    !endDate ||
    !startTime ||
    !endTime
  ) {
    unlinkFile.unlinkFile(req.file.path);
    return res.status(400).json({ error: "all fileds are required" });
  }

  const promoters = promoterId.split(",");
  const trueFalseArrayForPromoters = await checkPromotersValid.checkPromoters(
    promoters
  );

  for (let i = 0; i < trueFalseArrayForPromoters.length; i++) {
    if (trueFalseArrayForPromoters[i] === false) {
      unlinkFile.unlinkFile(req.file.path);
      return res.status(404).json({ error: "promoters not found" });
    }
  }

  const addEventQuery =
    "insert into event (name,venue,genres,promoterId,image,cost,age,visibility,description,startDate,endDate,startTime,endTime) values (?,?,?,?,?,?,?,?,?,?,?,?,?) ";

  conn.query(
    addEventQuery,
    [
      name,
      venue,
      genres,
      promoterId,
      image,
      cost,
      age,
      visibility,
      description,
      startDate,
      endDate,
      startTime,
      endTime,
    ],
    (error, result) => {
      if (error) {
        unlinkFile.unlinkFile(image);
        console.error(error);
        return res.status(500).json({ error: "Failed to add event" });
      }
      return res.status(200).json({ status: "success" });
    }
  );
};

//....................................... ADMIN can APPROVE EVENT .....................................//
const approveEvent = (req, res) => {
  const { id } = req.params;
  const approveEventQuery = "update event set approve = '1' where id = ?";

  conn.query(approveEventQuery, [id], (error, result) => {
    if (error) {
      console.error(error);
      return res.status(500).json({ error: "failed to approve event" });
    }
    return res.status(200).json({ result: "success" });
  });
};

//...................................... ADMIN can see ALL EVENT ......................................//
const eventList = (req, res) => {
  const eventListQuery = "select * from event order by startDate";
  conn.query(eventListQuery, (error, result) => {
    if (error) {
      console.error(error);
      return res.status(500).json({ error: "failed to get event list" });
    }
    if (result.length === 0)
      return res.status(404).json({ message: "No Event found" });
    return res.status(200).json(result  );
  });
};

//.......................... ADMIN can get DETAILS on particular EVENT by ID ..........................//
const particularEvent = (req, res) => {
  const { id } = req.params;
  const eventListQuery = "select * from event where id = ?";
  conn.query(eventListQuery, [id], (error, result) => {
    if (error) {
      console.error(error);
      return res.status(404).json({ error: "failed to get event list" });
    }
    if (result.length === 0)
      return res.status(404).json({ message: "No Event found" });
    return res.status(200).json( result );
  });
};

//.................................... ADMIN can DELETE EVENT using by ID ..............................//

 const deleteEvent = (req, res) => {
  const { id } = req.params;
  console.log(id)
  const getEvent = "select * from event where id = ? and status = 'active'";
  conn.query(getEvent, [id], (error, result) => {
    if (error) {
      console.error(error);
      return res.status(500).json({ error: "somthing went wrong" });
    }
    if(result.length === 0) return res.status(404).json({ error: "Event not found" });
    const deleteImage = result[0].image;
    if (result[0].length !== 0) {
      const deleteEventQuery =
        "update event set status = 'inactive' where id = ?";
      conn.query(deleteEventQuery, [id], (error, result) => {
        if (result.affectedRows === 1) {
          if(deleteImage) fs.unlinkSync(deleteImage);
          return res.status(200).json({ result: "success" });
        }
      });
    }
  });
}; 

//............................ ADMIN can see upcoming EVENTS from current date .........................//
const upcommingEvents = (req, res) => {
  const date = new Date();
  const upcommingEventQuery = "select * from event where startDate > ?";
  conn.query(upcommingEventQuery, [date], (error, result) => {
    if (error) {
      console.error(error);
      return res
        .status(500)
        .json({ error: "failed to fetch upcomming events" });
    }
    if (result.length === 0)
      return res.status(404).json({ result: "NO Upcomming Events" });
    return res.status(200).json({ result });
  });
};

//............................ ADMIN can see HISTORY of EVENTS from current date .......................//
const historyEvents = (req, res) => {
  const date = new Date();
  const upcommingEventQuery = "select * from event where startDate < ?";
  conn.query(upcommingEventQuery, [date], (error, result) => {
    if (error) {
      console.error(error);
      return res
        .status(500)
        .json({ error: "failed to fetch history of events" });
    }
    if (result.length === 0)
      return res.status(404).json({ result: "NO History of Events" });
    return res.status(200).json({ result: result });
  });
};

//........................................ ADMIN can Edit EVENT by id ..................................//
const editEvent = (req, res) => {
  const {name,venue,genres,promoterId,cost,age,visibility,description,startDate,endDate,startTime,endTime} = req.body;
  const { id } = req.params;
  const existingEventSearchQuery = "select * from event where id = ?";
  conn.query(existingEventSearchQuery, [id], async (error, result) => {
    try{
      if (result.length === 0) {
        if(req.file) unlinkFile.unlinkFile(req.file.path);
        return res.status(404).json({ error: "event not found" });
      }
      const updateQuery =
        "update event set name=?, venue=?, genres=?,promoterId=?,image = ?, cost=?, age=?, visibility=?, description = ?,startDate = ?,endDate = ? ,startTime = ? ,endTime = ?  where id = ?";
        let nameNew = name?name :result[0].name ;
        let venueNew = venue?venue :result[0].venue ;
        let genresNew = genres?genres :result[0].genres ;
        let promoterIdNew = promoterId?promoterId :result[0].promoterId ;
        let costNew = cost?cost :result[0].cost ;
        let ageNew = age?age :result[0].age ;
        let visibilityNew = visibility?visibility :result[0].visibility ;
        let descriptionNew = description?description :result[0].description ;
        let startDateNew = startDate?startDate :result[0].startDate ;
        let endDateNew = endDate?endDate :result[0].endDate ;
        let startTimeNew = startTime?startTime :result[0].startTime ;
        let endTimeNew = endTime?endTime :result[0].endTime ;
        let image = result[0].image;
        if (req.file) {
          unlinkFile.unlinkFile(result[0].image);
          image = req.file.path;
        }
        conn.query(
          updateQuery,
          [nameNew,venueNew,genresNew,promoterIdNew,image,costNew,ageNew,visibilityNew,descriptionNew,startDateNew,endDateNew,startTimeNew,endTimeNew,id],
          (error, result) => {
            if (error) {
              console.error(error);
              return res.status(500).json({ error: "failed to update" });
            }
            return res.status(200).json({ status: "success" });
          }
        );

    }catch(error){
      console.error(error);
      unlinkFile.unlinkFile(req.file.path);
      return res.status(500).json({ error: "failed to get event" });
    }
  });
};

//........................................ ADMIN create Promoter  ..................................//
const createPromoter = function (req, res) {
  const { name } = req.body;

  conn.query('SELECT * FROM promoters WHERE name = ?', [name], (err, result) => {
    if (err) {
      console.error('Error querying the database:', err);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }

    if (result.length === 0) {
      res.status(404).json({ error: 'Promoter not found' });
      return;
    }

  
  });
};

module.exports = {
  addEvent,
  eventList,
  particularEvent,
  deleteEvent,
  approveEvent,
  upcommingEvents,
  historyEvents,
  editEvent,
};
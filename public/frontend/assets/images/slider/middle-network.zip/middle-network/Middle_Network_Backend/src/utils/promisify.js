const conn = require("../config/connection");
const util = require("util");

const promisifyQuery = util.promisify(conn.query).bind(conn);

module.exports = {
    promisifyQuery
}
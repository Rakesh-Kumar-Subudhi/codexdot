const fs = require("fs");

const unlinkFile = async (path) => {
  try {
    await fs.unlinkSync(path);
  } catch (error) {
    throw error;
  }
};

module.exports = { unlinkFile };
const conn = require("../../config/connection");

const createPromoter = function (req, res) {
          const { name } = req.body;

          // Check if 'name' is null or empty
          if (!name) {
                    return res.status(400).json({ error: 'Name cannot be null or empty' });
          }

          conn.query('INSERT INTO promoters (name) VALUES (?)', [name], (err, result) => {
                    if (err) {
                              console.error('Error inserting promoter into the database:', err);
                              return res.status(500).json({ error: 'Internal server error' });
                    }

                    // Successfully inserted promoter into the database
                    res.status(201).json({ message: 'Promoter created successfully', promoterId: result.insertId });
          });
};

const updatePromoter = function (req, res) {
          const promoterId = req.params.id;
          const { name } = req.body;

          // Check if 'name' is null or empty
          if (!name) {
                    return res.status(400).json({ error: 'Name cannot be null or empty' });
          }

          // Update promoter in the database based on the promoter ID
          const updateQuery = 'UPDATE promoters SET name = ? WHERE id = ?';
          conn.query(updateQuery, [name, promoterId], (err, result) => {
                    if (err) {
                              console.error('Error updating promoter:', err);
                              return res.status(500).json({ error: 'Internal server error' });
                    }

                    if (result.affectedRows === 0) {
                              return res.status(404).json({ error: 'Promoter not found' });
                    }

                    // Successfully updated promoter
                    res.status(200).json({ message: 'Promoter updated successfully' });
          });
};

const getPromoterById =function(req, res) {
          const promoterId = req.params.id;
          const query = 'SELECT * FROM promoters WHERE id = ?';
        
          conn.query(query, [promoterId], (error, results) => {
            if (error) {
              console.error('Error fetching promoter:', error);
              res.status(500).send('Error fetching promoter');
            } else if (results.length === 0) {
              res.status(404).send('promoter not found');
            } else {
              res.status(200).json(results[0]);
            }
          });
        };


const getAllPromoter = function(req, res)  {
          const query = 'SELECT * FROM promoters';
        
          conn.query(query, (error, results) => {
            if (error) {
              console.error('Error fetching promoter:', error);
              res.status(500).send('Error fetching promoter');
            } else {
              res.status(200).json(results);
            }
          });
        };

  const deletePromoter = function(req,res) {
          const promoterId = req.params.id;
        
          // Query to delete a promoter by ID from the database
          const deleteQuery = 'DELETE FROM promoters WHERE id = ?';
        
          conn.query(deleteQuery, [promoterId], (err, result) => {
            if (err) {
              console.error('Error deleting the promoter:', err);
              return res.status(500).json({ error: 'Internal server error' });
            }
        
            // Check if no rows were affected (promoter not found)
            if (result.affectedRows === 0) {
              return res.status(404).json({ error: 'Promoter not found' });
            }
        
            // Successfully deleted the promoter
            res.status(200).json({ message: 'Promoter deleted successfully' });
          });
        };


module.exports = {
          createPromoter,
          updatePromoter,
          getPromoterById,
          getAllPromoter,
          deletePromoter
}
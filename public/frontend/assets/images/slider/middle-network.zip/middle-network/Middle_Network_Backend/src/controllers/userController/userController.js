const conn = require("../../config/connection");
let jwt = require("jsonwebtoken");
const otpGenerator = require('otp-generator');
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'monalisamahanta98@gmail.com',
    pass: 'Monalisa@1234',
  },
});


//------------------------------- User Login By email ---------------------------------------//

exports.userLogin = function (req, res) {
    const { email } = req.body;

    conn.query("SELECT * FROM users WHERE email = ?", [email], (err, results) => {
        if (err) {
            console.error("Error querying the database:", err);
            res.status(500).json({ error: "Internal server error" });
            return;
        }
        if (results.length === 0) {
            res.status(404).json({ error: "User not found" });
            return;
        }
        const user = results[0];

        req.session.user = { id: user.id, firstName: user.firstName, lastName:user.lastName, email:user.email};
        const dbUsermail = user.email;
        console.log(req.session.user);
        // Generate a JWT token
        const token = jwt.sign({ dbUsermail}, "USER");     
         res.status(200).json({ message: "Login successful", token });
    });
    
};

exports.signUp =  async (req, res) => {

    const { firstName,lastName,email,number,gender,dob } = req.body;
    if (!firstName || !lastName || !email || !number || !gender || !dob){
      return res.status(400).json({ error: "all fileds are required" });
    }

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
    if (!emailRegex.test(email)){
        return res.status(400).json({ error: "enter valid email" });
    }

    const existingUser = "select email from users where email = ?";
    conn.query(existingUser, [email], (error, result) => {
      if (error) {
        console.error(error);
        return res.status(500).json({ error: "failed to get user" });
      }
      if (result.length !== 0) {
        return res.status(400).json({ error: "user already exist" });
      }
      // Generate OTP
  const otp = otpGenerator.generate(6, { digits: true, lowerCaseAlphabets: false, upperCaseAlphabets: false, specialChars: false });

  const expiryTime = new Date();
  expiryTime.setMinutes(expiryTime.getMinutes() + 5); // Set OTP expiration time to 5 minutes

      const addUserQuery =
        "insert into users (firstName,lastName,email,number,gender,dob,otp,otpExpiresIn) values (?,?,?,?,?,?,?,?)";
      conn.query(
        addUserQuery,
        [
            firstName,
            lastName,
            email,
            number,
            gender,
            dob,
            otp, 
            expiryTime,
        ],
        (error, result) => {
          if (error) {
            console.error(error);
            return res.status(500).json({ error: "Failed to Add User" });
          }
          // return res.status(200).json({ status: "Success" });
          sendOtpEmail(email, otp);

        // Set user data in the session
        req.session.user = { email };
        res.send('OTP sent. Check your email.');
        // return res.status(500).json({ status: 'OTP sent. Check your email.'});
        }
      );
    });  
};

// Function to send OTP via email
function sendOtpEmail(email, otp) {
  const mailOptions = {
    from: 'monalisamahanta98@gmail.com',
    to: email,
    subject: 'OTP for complete the Sign Up.',
    text: `Your OTP for Sign Up is: ${otp}`,
};

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
}


// Route to handle OTP verification

exports.verifyotp = function (req, res){
  const { otp } = req.body;
  const { email } = req.body;

// Retrieve stored OTP and expiration time from the MySQL database

conn.query(
    'SELECT otp, otpExpiresIn FROM users WHERE email = ?',
    [email],
    (err, results) => {
      if (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
      } else {
        const storedOtp = results[0].otp;
        const expiryTime = new Date(results[0].otp_expiry);

        if (otp === storedOtp && new Date() < expiryTime) {
          res.send('OTP verified. Your Registration is completed.');
        } else {
          res.status(401).send('Invalid OTP or OTP expired');
        }
      }
    }
  )
}

exports.addReviews = async(req, res) =>{
  const id = req.session.user.id;    // get id from the session
  
  if(!req.file) {
      return res.status(400).json({error:"net profile pic"})
  }
  const photoRegex = /\.(jpg|jpeg|png|gif|bmp)$/i;

  if (!photoRegex.test(req.file.path)) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: "enter valid image" });
    }
  const photo = req.file.path;

  const {artistId, text, title, date, description} = req.body;
  conn.query('INSERT INTO reviews SET ?', 
  {artistId: artistId, userId:id, photo:photo, text:text, title:title, date:date, description:description}, 
  (error, results)=>{
      if (error){
          console.log(error);
          fs.unlinkSync(req.file.path);
          return res.status(500).json({error: 'Failed to add Reviews'});
      }
      return res.status(200).json({ message: 'Review stored successfully' })
  }) 
};


exports.getReviews = async(req, res) =>{
  const id = req.params.id;
  conn.query(
    'r.photo,r.text,r.date, r.title, r.description,u.firstName as userFirstName, u.lastName as userlastName,u.photo as userPhoto FROM reviews r JOIN users u ON r.userId = u.id WHERE r.artistId = ?'
    , [id], async(error, results)=>{
      if (error){
          console.log(error);
          res.status(500).json({ error: 'Internal Server Error' });
      } else{
          res.json(results);
      }

  })
}
const conn = require("../../config/connection");
let jwt = require("jsonwebtoken");
const fs = require("fs");
const bcrypt = require("bcrypt");
// const bcrypt = require('bcryptjs');


//------------------------------- Artist Login By email and password---------------------------------------//

exports.artistLogin = function (req, res) {
    const { email, password } = req.body;

    conn.query("SELECT * FROM artist WHERE email = ?", [email], (err, results) => {
        if (err) {
            console.error("Error querying the database:", err);
            res.status(500).json({ error: "Internal server error" });
            return;
        }
        if (results.length === 0) {
            res.status(404).json({ error: "Artist not found" });
            return;
        }
        const artist = results[0];
        bcrypt.compare(password, artist.password, (err, passwordMatch) => {
            if (err) {
              console.error("Error comparing passwords:", err);
              res.status(500).json({ error: "Internal server error" });
              return;
            }
      
            if (!passwordMatch) {
              res.status(401).json({ error: "Invalid password" });
              return;
            }
      
            // Store user details in the session
            req.session.user = { id: results[0].id, artist_name: results[0].artist_name, email:results[0].email, spotify_id:results[0].spotify_id};
            const dbUsermail = results[0].email;
            const dbUserpass = results[0].password;
            console.log(req.session.user);
            // Generate a JWT token
            const token = jwt.sign({ dbUsermail, dbUserpass }, "ARTIST");     
            res.status(200).json({ message: "Login successful", token });
          });

    })
};

exports.signUp =  async (req, res) => {

  if(!req.file) return res.status(400).json({error:"net profile pic"})
  const profile_pic = req.file.path;
  const { artist_name, email, password, instagram_id, spotify_id, contact_no } = req.body;
  if (!artist_name || !email || !password || !instagram_id || !spotify_id || !contact_no){
    return res.status(400).json({ error: "all fileds are required" });
  }

  const photoRegex = /\.(jpg|jpeg|png|gif|bmp)$/i;
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const passwordRegex =/^[a-zA-Z0-9!@#$%^&*]{6,16}$/;

  if (!emailRegex.test(email))
    return res.status(400).json({ error: "enter valid mail" });
  if (!passwordRegex.test(password))
    return res.status(400).json({ error: "enter strong passowrd add artist" });
  if (!photoRegex.test(req.file.path)) {
    fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: "enter valid image" });
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const existingArtist = "select email from artist where email = ?";
  conn.query(existingArtist, [email], (error, result) => {
    if (error) {
      console.error(error);
      return res.status(500).json({ error: "failed to get artist" });
    }
    if (result.length !== 0) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: "user already exist" });
    }
    const addArtistQuery =
      "insert into artist (artist_name, email, password,profile_pic, instagram_id, spotify_id, contact_no) values (?,?,?,?,?,?,?)";
    conn.query(
      addArtistQuery,
      [
        artist_name,
        email,
        hashedPassword,
        profile_pic,
        instagram_id,
        spotify_id,
        contact_no,
      ],
      (error, result) => {
        if (error) {
          console.error(error);
          fs.unlinkSync(req.file.path);
          return res.status(500).json({ error: "Failed to Add Artist" });
        }
        return res.status(200).json({ status: "Success" });
      }
    );
  });

};

async function hashPassword(uppassword) {
  const saltRounds = 10;
  try {
      const hash = await bcrypt.hash(uppassword, saltRounds);
      return hash;
  } catch (error) {
      throw error;
  }
}

exports.editArtist =  async (req, res) => {
// const id = req.session.user.id;
const { id } = req.params;
const { artist_name, email, password, contact_no } = req.body;

const hashedPassword = await hashPassword(password);

  conn.query('UPDATE artist SET artist_name = ?, email = ?, password = ?, contact_no = ? WHERE id = ?', [artist_name, email, hashedPassword, contact_no, id], 
  (error, results) => {
    if (error) {
        console.log(error);
        return res.status(500).json({ error: 'Internal server error' });
    } else {
      res.status(200).json({ message: "Update successful"});
    }
  });

};

// Route to logout
exports.signOut = (req, res) => {
  req.session.destroy((err) => {
      if (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
      }
      else {
        res.send('signOut successful');
      }
  });
};

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './main/navbar/navbar.component';
import { HomeComponent } from './pages/home/home.component';
import { FooterComponent } from './main/footer/footer.component';
import { MusicComponent } from './pages/music/music.component';
import { EventComponent } from './pages/event/event.component';
import { MagazineComponent } from './pages/magazine/magazine.component';
import { AboutComponent } from './pages/about/about.component';
import { WelcomeComponent } from './others/welcome/welcome.component';
import { ArtistLoginComponent } from './others/artist-login/artist-login.component';
import { ArtistSignupComponent } from './others/artist-signup/artist-signup.component';
import { UserLoginComponent } from './others/user-login/user-login.component';

import { UserSignupComponent } from './others/user-signup/user-signup.component';
import { OtpScreenComponent } from './others/otp-screen/otp-screen.component';

import { NotifierModule } from 'angular-notifier';
import{ NgOtpInputModule } from 'ng-otp-input';
import { PodcastComponent } from './pages/podcast/podcast.component';





@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    FooterComponent,
    MusicComponent,
    EventComponent,
    MagazineComponent,
    AboutComponent,
    WelcomeComponent,
    ArtistLoginComponent,
    ArtistSignupComponent,
    UserLoginComponent,
    UserSignupComponent,
    OtpScreenComponent,
    PodcastComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
     NgbModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NotifierModule,
    NgOtpInputModule,
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

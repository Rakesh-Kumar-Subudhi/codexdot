import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  isLoggedIn: boolean = false;  
  redirectUrl:any;
  private baseUrl: string = 'http://localhost:3000/artist';
 
  constructor(private http: HttpClient,private router:Router ) { }

  sendOTP(data: any): Observable<any> {
    this.isLoggedIn = true;
    if (this.redirectUrl) {
      this.router.navigate([this.redirectUrl]);
      this.redirectUrl = null;
    }
    console.log("I am server");
    return this.http.post(`${this.baseUrl}/sendOtp`, data);
  }

  userLogin(data: any,id:number): Observable<any> {
    this.isLoggedIn = true;
    if (this.redirectUrl) {
      this.router.navigate([this.redirectUrl]);
      this.redirectUrl = null;
    }
    console.log("I am server");
    return this.http.post(`${this.baseUrl}/login`, data);
  }
  signUp(inputData: any): Observable<any> {
    console.log("I am server");
    return this.http.post(`${this.baseUrl}/register`, inputData);
  }


}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { MusicComponent } from './pages/music/music.component';
import { EventComponent } from './pages/event/event.component';
import { MagazineComponent } from './pages/magazine/magazine.component';
import { AboutComponent } from './pages/about/about.component';
import { WelcomeComponent } from './others/welcome/welcome.component';
import { ArtistLoginComponent } from './others/artist-login/artist-login.component';
import { ArtistSignupComponent } from './others/artist-signup/artist-signup.component';
import { UserLoginComponent } from './others/user-login/user-login.component';
import { UserSignupComponent } from './others/user-signup/user-signup.component';
import { OtpScreenComponent } from './others/otp-screen/otp-screen.component';
import { PodcastComponent } from './pages/podcast/podcast.component';


const routes: Routes = [
    {path:'',redirectTo:'home', pathMatch:'full'},
    {path:'home',component:HomeComponent},
    {path:'music',component:MusicComponent},
    {path:'event',component:EventComponent},
    {path:'magazine',component:MagazineComponent},
    {path:'about',component:AboutComponent},
    {path:'welcome',component:WelcomeComponent},
    {path:'podcast',component:PodcastComponent},

    {path:'otp',component:OtpScreenComponent},


    {path:'artist/Login',component:ArtistLoginComponent},
    {path:'artist/Signup',component:ArtistSignupComponent},

    {path:'user/Login',component:UserLoginComponent},
    {path:'user/Signup',component:UserSignupComponent},




    


    
    

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { ServiceService } from 'src/app/service.service';
import { catchError, switchMap, tap } from 'rxjs/operators';
import { EMPTY, throwError } from 'rxjs';
import { Renderer2, ElementRef } from '@angular/core';
import { UserModel } from 'src/app/models/artist.model';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-otp-screen',
  templateUrl: './otp-screen.component.html',
  styleUrls: ['./otp-screen.component.css']
})
export class OtpScreenComponent {
  formGroup!: FormGroup;
  userModelObj: UserModel = new UserModel();
  userData:any;
  otp:any
  userId: string | undefined; 
  constructor(private service: ServiceService, private fb: FormBuilder,private router : Router,private notifier: NotifierService,private renderer: Renderer2, private el: ElementRef,   private activatedRoute: ActivatedRoute){}
  
  ngOnInit(): void {  
    this.formGroup = this.fb.group({
      email:new FormControl('', [Validators.required]), 
      otp: new FormControl('', [Validators.required])    
    });

  }
  
  
  

  onOtpChange(otp: string) {
    this.formGroup.get('otp')?.setValue(otp);
  }

  loginProcess() {
    const otp = this.formGroup.get('otp')?.value;
    const userId = this.activatedRoute.snapshot.paramMap.get('userId');
    if (otp && otp.length === 4) {
      const data = {
        otp: otp,
        id: userId // Assuming you have the user ID available in your component
      };
  
      // Assuming you have a function to verify OTP and initiate login
      this.verifyOtpAndLogin(data);
    } else {
      console.log('Please enter a valid OTP.');
    }
  }

  verifyOtpAndLogin(data: any) {
    // Assuming you have a service method to verify OTP and initiate login
    this.service.userLogin(data, data.id).pipe(
      tap((res) => {
        console.log(res);
        if (res.token) {
          console.log('OTP verification success. Initiating login.');
        } else {
          console.log('OTP verification failed.');
        }
      }),
      catchError((error) => {
        console.log('Error during OTP verification:', error);
        return EMPTY;
      })
    ).subscribe();
  }
  

}
    
  
  
  

  
  
  


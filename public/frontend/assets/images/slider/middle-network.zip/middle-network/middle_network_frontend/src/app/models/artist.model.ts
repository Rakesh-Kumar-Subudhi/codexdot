export class UserModel {
          id: number = 0;
          firstName: string = '';
          lastName: string = '';
          email:string = '';
          otp:any;
          phone:any;
          password:string='';
          date_of_birth: string = '';
          time_of_birth: string = '';
          place_of_birth: string = '';
          gender: string = '';
          status:string='';
        }

        export class artistModel {
          id: number = 0;
          artist_name:string ='' ;
          email:string = '';
          password:string ='';
          profile_pic:any;
          instagram_id:string ='';
          spotify_id:string = '';
          contact_no:string ='';
          status:string='';
        }
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service.service';
import { NotifierService } from 'angular-notifier';
import { catchError, tap } from 'rxjs/operators';
import { EMPTY } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  formGroup!: FormGroup;
  // msgData:boolean;
  // showPassword : boolean = false;

  constructor(private service: ServiceService, private fb: FormBuilder, private router: Router, private notifier: NotifierService, private activatedRoute: ActivatedRoute) { }
  ngOnInit(): void {
    this.formGroup = this.fb.group({
      email: new FormControl('', [Validators.required, Validators.email])
    });
  }

  get email() {
    return this.formGroup.get('email')
  }



  loginProcess() {
    if (this.formGroup.valid) {
      this.service.sendOTP(this.formGroup.value).pipe(
        tap((res) => {
          console.log('API Response:', res);
          if (res.status === 'success') {
            console.log('API call was successful');

            // Retrieve userId from route parameters

            const userId = this.formGroup.value.email
            // Navigate to OTP page with userId
            console.log(userId);

            this.router.navigate([`/otp/${userId}`]);
          } else {
            console.log('API call was not successful');
          }
        }),
        catchError((error) => {
          console.error('An error occurred:', error);
          return EMPTY;
        })
      ).subscribe();
    }
  }




}




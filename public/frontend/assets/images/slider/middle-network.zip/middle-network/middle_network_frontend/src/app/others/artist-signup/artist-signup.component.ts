import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service.service';
import { catchError, tap } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-artist-signup',
  templateUrl: './artist-signup.component.html',
  styleUrls: ['./artist-signup.component.css']
})
export class ArtistSignupComponent {
  formGroup!: FormGroup;

  constructor( private service : ServiceService ,private fb: FormBuilder,private router : Router) { }

  ngOnInit() {
    this.registerForm();
  }

  
  registerForm() {
    this.formGroup = this.fb.group({
      name: new FormControl('',Validators.required),
      email: new FormControl('', [Validators.required, Validators.email]),
      phone: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
    });
  }

  get name() {
    return this.formGroup.get('name');
  }
  
    get email() {
    return this.formGroup.get('email');
  }
  get phone() {
    return this.formGroup.get('phone');
  }

  signUpProcess() {
    console.log(this.formGroup.value);
  
    if (this.formGroup.valid) {
      const uniqueIdentifier = this.formGroup.value.email
        ? this.formGroup.value.email // Use email if provided
        : this.formGroup.value.phone; // Use phone number if email is not provided
  
      if (!uniqueIdentifier) {
        console.error('Either email or phone  is required.');
        return; // Exit the function if neither email nor phone number is provided
      }
  
      this.service.signUp(this.formGroup.value).pipe(
        tap((res) => {
          if (res.status === 'success') {
            console.log('API call was successful');
  
            // Assuming the response contains the userId
            const uniqueIdentifier = res.uniqueIdentifier;
  
            // Navigate to OTP page with userId
            this.router.navigate([`/otp/${uniqueIdentifier}`]);
          } else {
            console.log('API call was not successful');
          }
        }),
        catchError(error => {
          console.error('Error during signup:', error);
          // Handle error appropriately (e.g., display error message)
          return throwError(error); // Re-throw the error after handling
        })
      ).subscribe(); // Subscribe to trigger the HTTP request
    } else {
      // Handle form validation errors
      console.error('Form is not valid.');
    }
  }
  
  

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-artist-login',
  templateUrl: './artist-login.component.html',
  styleUrls: ['./artist-login.component.css']
})
export class ArtistLoginComponent {

}
